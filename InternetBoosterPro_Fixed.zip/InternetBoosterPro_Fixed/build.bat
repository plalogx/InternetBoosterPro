@echo off
setlocal

echo ==========================================
echo   InternetBooster Pro - Build
echo ==========================================
echo.

cd /d "%~dp0"

if not exist "InternetBoosterPro.csproj" (
    echo [ERROR] InternetBoosterPro.csproj not found next to build.bat.
    echo Make sure build.bat is in the same folder as the .csproj file.
    echo.
    pause
    exit /b 1
)

where dotnet >nul 2>nul
if errorlevel 1 (
    echo [ERROR] "dotnet" command not found.
    echo It looks like .NET 8 SDK is not installed.
    echo Download it here: https://dotnet.microsoft.com/download/dotnet/8.0
    echo After installing, restart your computer and run build.bat again.
    echo.
    pause
    exit /b 1
)

echo [1/2] Restoring dependencies (dotnet restore)...
dotnet restore
if errorlevel 1 (
    echo.
    echo [ERROR] dotnet restore failed. See the output above.
    pause
    exit /b 1
)

echo.
echo [2/2] Building the project (dotnet build -c Release)...
dotnet build -c Release
if errorlevel 1 (
    echo.
    echo [ERROR] Build failed. See the output above.
    pause
    exit /b 1
)

echo.
echo ==========================================
echo   Build succeeded!
echo ==========================================
echo The .exe file is located at:
echo   bin\Release\net8.0-windows\InternetBoosterPro.exe
echo.
echo You can run run.bat to launch the app right away.
echo.
pause
