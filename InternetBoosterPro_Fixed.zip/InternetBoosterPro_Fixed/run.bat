@echo off
setlocal

cd /d "%~dp0"

set "EXE_PATH=bin\Release\net8.0-windows\InternetBoosterPro.exe"

if not exist "%EXE_PATH%" (
    echo No build found yet - building the project first...
    echo.
    call "%~dp0build.bat"
)

if exist "%EXE_PATH%" (
    echo Starting InternetBoosterPro.exe ...
    start "" "%EXE_PATH%"
) else (
    echo [ERROR] Could not find or build %EXE_PATH%
    echo Check the error messages above from build.bat.
    pause
)
