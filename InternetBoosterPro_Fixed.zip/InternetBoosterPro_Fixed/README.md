# InternetBooster Pro (C# / .NET 8 / WPF)

Полный переход с Python (PyQt6) на C# (.NET 8, WPF) сетевого инструмента
для Windows: мониторинг сети, DNS/TCP-оптимизация, игровой режим,
автозапуск, свой MTProto-прокси и SOCKS5-прокси с опциональной
интеграцией Cloudflare WARP.

---

## Быстрый старт (пошагово, для тех, кто впервые собирает .NET-проект)

### Шаг 1. Установите .NET 8 SDK

1. Откройте страницу: https://dotnet.microsoft.com/download/dotnet/8.0
2. Скачайте **".NET 8.0 SDK"** (именно **SDK**, не "Runtime" — Runtime для сборки не подходит), колонку **Windows x64**.
3. Установите как обычную программу (Далее → Далее → Установить).
4. Перезапустите компьютер (иногда обязательно, чтобы обновился PATH).

Проверка, что всё встало: откройте обычную командную строку (`cmd`,
не PowerShell) и наберите:
```
dotnet --version
```
Должно вывести что-то вроде `8.0.xxx`. Если пишет "команда не найдена" — SDK не установился или нужен перезапуск ПК.

### Шаг 2. Распакуйте архив проекта

Распакуйте `InternetBoosterPro_CSharp.zip` в удобное место, например на Рабочий стол.
После распаковки у вас должна получиться такая структура:

```
Desktop\
  InternetBoosterPro_CSharp\
    InternetBoosterPro\              <-- ВОТ ЭТА ПАПКА НАМ НУЖНА
      InternetBoosterPro.csproj      <-- главный файл проекта
      build.bat                      <-- собрать проект (двойной клик)
      run.bat                        <-- собрать (если нужно) и запустить
      App.xaml
      App.xaml.cs
      Core\
      UI\
      Tray\
      assets\
      README.md (этот файл)
```

### Шаг 3. Соберите проект через build.bat

Никакой PowerShell не нужен. Просто откройте папку `InternetBoosterPro`
(там, где лежит `.csproj`) в Проводнике Windows и **дважды кликните
по файлу `build.bat`**.

(Сообщения в самом окне консоли на английском — это специально, чтобы
`cmd.exe` не портил русские буквы из-за особенностей своей кодировки.
Весь остальной текст в этом README — на русском.)

Откроется чёрное окно консоли, которое само:
1. Проверит, что рядом есть `.csproj` и установлен `dotnet`;
2. Выполнит `dotnet restore` (скачает нужные пакеты, нужен интернет);
3. Выполнит `dotnet build -c Release` (скомпилирует проект).

В конце вывода должно быть написано что-то вроде:
```
Сборка выполнена успешно.
    Предупреждений: 0
    Ошибок: 0
```
(на английском — `Build succeeded.`)

Если видите **любые строки со словом `error`** — скопируйте весь вывод
консоли и пришлите его целиком, не пересказывайте своими словами: точный
текст ошибки почти всегда указывает на точную причину. Окно консоли не
закроется само — в конце будет строка `Нажмите любую клавишу для продолжения . . .`,
можно просто закрыть окно.

### Шаг 4. Запустите приложение через run.bat

После успешной сборки дважды кликните по файлу **`run.bat`** — он
найдёт `InternetBoosterPro.exe` и сразу его откроет (а если сборки ещё
не было, сначала соберёт проект автоматически, вызвав `build.bat`).

Готовый .exe при этом лежит здесь:
```
InternetBoosterPro\bin\Release\net8.0-windows\InternetBoosterPro.exe
```

Можно также запускать его напрямую двойным щелчком — это уже рабочее
приложение. **Важно:** рядом с .exe в этой же папке лежит куча
`.dll`-файлов — их нельзя удалять и нельзя переносить один .exe без
них, иначе приложение не запустится (см. Шаг 5, если нужен один
самостоятельный файл).

### Шаг 5 (необязательно). Собрать один самостоятельный .exe без .dll рядом

Если хотите один файл, который можно скопировать/отправить отдельно,
выполните эту команду вручную из обычной командной строки (`cmd`) в
папке проекта:

```
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true
```

Готовый файл появится тут:
```
InternetBoosterPro\bin\Release\net8.0-windows\win-x64\publish\InternetBoosterPro.exe
```

Он самодостаточный (~60-80 МБ, т.к. включает в себя весь .NET), но
запускается на компьютере без установленного .NET.

---

## Частые ошибки и их решение

### `MSB1003: укажите проект или файл решения`
Значит `build.bat` запущен не из той папки, или файл `InternetBoosterPro.csproj`
случайно оказался не рядом с `build.bat`/`run.bat`. Проверьте, что все файлы
проекта (включая `.csproj`) лежат в той же папке, что и `build.bat`.

### `error CS0104: "Application"/"UserControl" является неоднозначной ссылкой`
Эта ошибка уже исправлена в текущей версии проекта (в `.csproj` добавлена
строка, убирающая конфликт между WPF и Windows Forms). Если вы всё ещё
видите её — значит, у вас старая версия архива; скачайте текущую.

### `dotnet: команда не найдена` / `не является внутренней или внешней командой`
.NET SDK не установлен или не подхватился в PATH. Переустановите SDK
(Шаг 1) и перезапустите компьютер.

### Сборка очень долго стоит на `Restoring...`
Обычно проблема с доступом к NuGet (корпоративный прокси/VPN/антивирус).
Попробуйте:
```powershell
dotnet nuget locals all --clear
dotnet restore
```

### Программа собралась, но при запуске сразу закрывается / ничего не видно
Приложение сворачивается в системный трей при закрытии окна (это
задумано, как в оригинале на Python) — поищите иконку в трее (стрелочка
"^" рядом с часами в панели задач).

---

## Структура проекта (соответствие исходным .py модулям)

| C# | Python (оригинал) |
|---|---|
| `Core/Config.cs` | `core/config.py` |
| `Core/Logger.cs` | `core/logger.py` |
| `Core/Admin.cs` | `core/admin.py` |
| `Core/Adapter.cs` | `core/adapter.py` |
| `Core/Background.cs` | `core/background.py` |
| `Core/Backup.cs` | `core/backup.py` |
| `Core/CoreGaming.cs` | `core/core_gaming.py` |
| `Core/DnsManager.cs` | `core/dns.py` |
| `Core/NetworkMonitor.cs` | `core/network.py` |
| `Core/Notifier.cs` | `core/notifier.py` |
| `Core/Optimizer.cs` | `core/optimizer.py` |
| `Core/Scheduler.cs` | `core/scheduler.py` |
| `Core/Startup.cs` | `core/startup.py` |
| `Core/TcpTools.cs` | `core/tcp.py` |
| `Core/WarpManager.cs` | `core/warp_manager.py` |
| `Core/AesCtr.cs` | (часть `cryptography` из mtproto_proxy.py / mtproto_selftest.py) |
| `Core/MtprotoSecret.cs` | `core/mtproto_secret.py` |
| `Core/MtprotoProxy.cs` | `core/mtproto_proxy.py` |
| `Core/MtprotoSelftest.cs` | `core/mtproto_selftest.py` |
| `Core/Socks5Proxy.cs` | `core/socks5_proxy.py` |
| `Tray/TrayIconManager.cs` | `tray/tray_tray_icon.py` |
| `UI/MainWindow.xaml(.cs)` | `ui/main_window.py` |
| `UI/DashboardControl.xaml(.cs)` | `ui/dashboard.py` |
| `UI/SettingsControl.xaml(.cs)` | `ui/settings.py` |
| `UI/LogsControl.xaml(.cs)` | `ui/logs.py` |
| `UI/SecretWidgetControl.xaml(.cs)` | `ui/secret_widget.py` |
| `UI/WarpWidgetControl.xaml(.cs)` | `ui/warp_widget.py` |
| `UI/MtprotoWidgetControl.xaml(.cs)` | `ui/mtproto_widget.py` |
| `UI/Socks5WidgetControl.xaml(.cs)` | `ui/socks5_widget.py` |
| `App.xaml(.cs)` | `main.py` |

## Замечания по переносу

- **PyQt6 → WPF**: вкладки (`QTabWidget`) стали `TabControl`, окно
  сворачивается в трей вместо закрытия (`OnClosing` → `e.Cancel = true`).
- **Трей-иконка**: в WPF нет прямого аналога `QSystemTrayIcon`, поэтому
  используется `System.Windows.Forms.NotifyIcon` (`UseWindowsForms=true`
  в `.csproj`; конфликт имён с WPF устранён через `<Using Remove=".../>`
  в `.csproj` и явные `using`-алиасы в коде).
- **AES-256-CTR**: .NET не имеет встроенного режима CTR для `Aes`, поэтому
  добавлен `Core/AesCtr.cs` — реализация через AES-ECB на счётчике,
  побайтовый XOR с keystream, побитово совместимая с
  `cryptography.hazmat.primitives.ciphers.modes.CTR` из Python.
- **asyncio → Task/TcpListener**: оба прокси-сервера (`MtProxyServer`,
  `Socks5ProxyServer`) переписаны на `TcpListener` + `async/await` вместо
  `asyncio.start_server`, с тем же протокольным поведением.
- **QTimer → DispatcherTimer / System.Timers.Timer**: `AutoOptimizer`
  использует `System.Timers.Timer` и обычные события
  (аналог `pyqtSignal`), таймеры интерфейса — `DispatcherTimer`.
- **winotify → NotifyIcon.ShowBalloonTip**: показ уведомлений реализован
  через баллун иконки в трее вместо отдельного пакета `winotify`.
- Все сетевые команды (`netsh`, `ipconfig`, `arp`, `nbtstat`) вызываются
  так же, как в оригинале, через дочерний процесс `cmd.exe`.

## Безопасность / права администратора

Приложение запускается как обычный процесс (`asInvoker`, см.
`app.manifest`) и само проверяет права (`Core.Admin.IsAdmin()`),
предлагая перезапуск от администратора там, где это нужно (открытие
портов в брандмауэре, изменение DNS/TCP, автозапуск) — то есть ведёт
себя так же, как и Python-версия.
