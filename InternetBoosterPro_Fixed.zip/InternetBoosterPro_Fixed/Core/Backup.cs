using System;
using System.IO;
using System.Text.Json;

namespace InternetBoosterPro.Core
{
    public class BackupData
    {
        public string Date { get; set; } = "";
        public AppConfig? Settings { get; set; }
    }

    /// <summary>
    /// Сохранение/загрузка backup сетевых настроек. Аналог core/backup.py.
    /// </summary>
    public static class Backup
    {
        private const string BackupFile = "logs/network_backup.json";

        public static void SaveBackup(AppConfig data)
        {
            Directory.CreateDirectory("logs");

            var backup = new BackupData
            {
                Date = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.ffffff"),
                Settings = data,
            };

            var options = new JsonSerializerOptions { WriteIndented = true };
            File.WriteAllText(BackupFile, JsonSerializer.Serialize(backup, options), System.Text.Encoding.UTF8);

            Logger.Log("Создан backup сетевых настроек");
        }

        public static BackupData? LoadBackup()
        {
            if (!File.Exists(BackupFile))
                return null;

            var json = File.ReadAllText(BackupFile, System.Text.Encoding.UTF8);
            return JsonSerializer.Deserialize<BackupData>(json);
        }
    }
}
