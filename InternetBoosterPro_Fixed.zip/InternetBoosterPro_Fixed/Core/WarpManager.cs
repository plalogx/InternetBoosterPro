using System;
using System.Diagnostics;
using System.Text.Json;
using System.Threading;

namespace InternetBoosterPro.Core
{
    /// <summary>
    /// Обёртка над warp-cli (Cloudflare WARP). Аналог core/warp_manager.py.
    /// </summary>
    public class WarpManager
    {
        public bool Available { get; }
        private readonly string? _warpCliPath;

        public WarpManager()
        {
            _warpCliPath = FindWarpCli();
            Available = _warpCliPath != null;
        }

        private static string? FindWarpCli()
        {
            var exeNames = OperatingSystem.IsWindows() ? new[] { "warp-cli.exe", "warp-cli" } : new[] { "warp-cli" };
            var pathEnv = Environment.GetEnvironmentVariable("PATH") ?? "";

            foreach (var dir in pathEnv.Split(System.IO.Path.PathSeparator, StringSplitOptions.RemoveEmptyEntries))
            {
                foreach (var exe in exeNames)
                {
                    var full = System.IO.Path.Combine(dir, exe);
                    if (System.IO.File.Exists(full))
                        return full;
                }
            }

            if (OperatingSystem.IsWindows())
            {
                var possibleDirs = new[]
                {
                    System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Cloudflare", "Cloudflare WARP"),
                    System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Cloudflare", "Cloudflare WARP"),
                    System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs", "Cloudflare WARP"),
                    System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Cloudflare", "WARP"),
                    System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Cloudflare", "WARP"),
                };

                foreach (var dir in possibleDirs)
                {
                    if (string.IsNullOrWhiteSpace(dir) || !System.IO.Directory.Exists(dir))
                        continue;

                    foreach (var exe in exeNames)
                    {
                        var full = System.IO.Path.Combine(dir, exe);
                        if (System.IO.File.Exists(full))
                            return full;
                    }
                }
            }

            return null;
        }

        private (bool Ok, string Text) Run(params string[] args)
        {
            if (!Available)
                return (false, "warp-cli не найден");

            try
            {
                var psi = new ProcessStartInfo
                {
                    FileName = _warpCliPath ?? "warp-cli",
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    CreateNoWindow = true,
                };

                foreach (var a in args) psi.ArgumentList.Add(a);

                using var process = Process.Start(psi);
                if (process == null) return (false, "не удалось запустить warp-cli");

                var stdout = process.StandardOutput.ReadToEnd();
                var stderr = process.StandardError.ReadToEnd();

                if (!process.WaitForExit(15_000))
                {
                    try { process.Kill(); } catch { /* ignore */ }
                    return (false, "warp-cli: таймаут");
                }

                var text = (stdout + stderr).Trim();
                return (process.ExitCode == 0, text);
            }
            catch (Exception e)
            {
                return (false, e.Message);
            }
        }

        public (bool Ok, string Text) Connect() => Run("connect");
        public (bool Ok, string Text) Disconnect() => Run("disconnect");
        public (bool Ok, string Text) Status() => Run("-j", "status");
        public (bool Ok, string Text) RegistrationShow() => Run("-j", "registration", "show");
        public (bool Ok, string Text) Register() => Run("--accept-tos", "registration", "new");

        public bool IsRegistered()
        {
            if (!Available)
                return false;

            var (ok, text) = RegistrationShow();
            if (!ok || string.IsNullOrWhiteSpace(text))
                return false;

            try
            {
                using var document = JsonDocument.Parse(text);
                return document.RootElement.TryGetProperty("id", out _);
            }
            catch
            {
                return false;
            }
        }

        public bool EnsureRegistered(Action<string>? onLog = null)
        {
            var log = onLog ?? (_ => { });
            if (!Available)
            {
                log("warp-cli не найден — регистрация WARP невозможна");
                return false;
            }

            if (IsRegistered())
                return true;

            log("WARP не зарегистрирован, пробую зарегистрировать...");
            var (ok, text) = Register();
            log(text);
            return ok;
        }

        public static bool IsConnectedText(string text)
        {
            var lower = text.ToLowerInvariant();
            var connected = lower.Contains("connected") || lower.Contains("подключ");
            var disconnected = lower.Contains("disconnected") || lower.Contains("отключ");
            return connected && !disconnected;
        }

        public static bool IsDisconnectedText(string text)
        {
            var lower = text.ToLowerInvariant();
            return lower.Contains("disconnected") || lower.Contains("отключ");
        }

        public bool IsConnected()
        {
            var (ok, text) = Status();
            return ok && IsConnectedText(text);
        }

        /// <summary>
        /// Проверяет, подключён ли WARP, и если нет - включает его и ждёт подключения
        /// до waitSeconds секунд. Используется прокси-серверами (SOCKS5/MTProto).
        /// </summary>
        public bool EnsureConnected(int waitSeconds = 10, Action<string>? onLog = null)
        {
            var log = onLog ?? (_ => { });

            if (!Available)
            {
                log("warp-cli не найден — WARP не будет использован");
                return false;
            }

            if (!EnsureRegistered(log))
            {
                log("Регистрация WARP не удалась — подключение невозможно.");
                return false;
            }

            if (IsConnected())
            {
                log("WARP уже подключён");
                return true;
            }

            log("WARP не подключён, пробую включить...");
            Connect();

            for (var i = 0; i < waitSeconds; i++)
            {
                Thread.Sleep(1000);

                if (IsConnected())
                {
                    log("WARP подключён");
                    return true;
                }
            }

            log("Не удалось дождаться подключения WARP — трафик пойдёт напрямую, пока WARP не будет подключён вручную (вкладка ☁ WARP).");
            return false;
        }
    }
}
