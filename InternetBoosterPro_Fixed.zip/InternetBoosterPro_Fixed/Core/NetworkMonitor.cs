using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.NetworkInformation;
using System.Threading;

namespace InternetBoosterPro.Core
{
    public class SpeedResult
    {
        public double Download { get; set; }
        public double Upload { get; set; }
    }

    /// <summary>
    /// Мониторинг сети: потери пакетов, список адаптеров, скорость.
    /// Аналог core/network.py.
    /// </summary>
    public class NetworkMonitor
    {
        public static readonly NetworkMonitor Instance = new();

        // -----------------------
        // Потери пакетов
        // -----------------------
        public string PacketLoss()
        {
            try
            {
                var psi = new ProcessStartInfo
                {
                    FileName = "ping",
                    Arguments = "-n 10 8.8.8.8",
                    RedirectStandardOutput = true,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                };

                using var process = Process.Start(psi);
                if (process == null) return "0%";

                var output = process.StandardOutput.ReadToEnd();
                process.WaitForExit(15000);

                foreach (var line in output.Split('\n'))
                {
                    if (line.Contains('%'))
                    {
                        var parts = line.Split(',');
                        foreach (var p in parts)
                        {
                            if (p.Contains('%'))
                                return p.Trim();
                        }
                    }
                }
            }
            catch (Exception error)
            {
                Logger.Log($"Ошибка замера потерь пакетов: {error.Message}");
            }

            return "0%";
        }

        // -----------------------
        // Сетевые адаптеры
        // -----------------------
        public List<string> Adapters()
        {
            return NetworkInterface.GetAllNetworkInterfaces()
                .Where(nic => nic.OperationalStatus == OperationalStatus.Up)
                .Select(nic => nic.Name)
                .ToList();
        }

        // -----------------------
        // Скорость сети
        // -----------------------
        public SpeedResult SpeedTest()
        {
            var (recvBefore, sentBefore) = TotalBytes();
            Thread.Sleep(1000);
            var (recvAfter, sentAfter) = TotalBytes();

            var download = (recvAfter - recvBefore) / 1024.0;
            var upload = (sentAfter - sentBefore) / 1024.0;

            return new SpeedResult
            {
                Download = Math.Round(download, 2),
                Upload = Math.Round(upload, 2),
            };
        }

        private static (long recv, long sent) TotalBytes()
        {
            long recv = 0, sent = 0;

            foreach (var nic in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (nic.OperationalStatus != OperationalStatus.Up) continue;
                if (nic.NetworkInterfaceType == NetworkInterfaceType.Loopback) continue;

                try
                {
                    var stats = nic.GetIPv4Statistics();
                    recv += stats.BytesReceived;
                    sent += stats.BytesSent;
                }
                catch
                {
                    // некоторые адаптеры могут не отдавать статистику
                }
            }

            return (recv, sent);
        }
    }
}
