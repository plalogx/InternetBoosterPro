using System;
using System.Security.Cryptography;

namespace InternetBoosterPro.Core
{
    /// <summary>
    /// Генерация и валидация MTProto secret. Аналог core/mtproto_secret.py.
    /// </summary>
    public static class MtprotoSecret
    {
        public static string Generate(int length = 32)
        {
            if (length < 16) length = 16;
            return RandomNumberGenerator.GetHexString(length * 2, lowercase: true);
        }

        public static string GenerateShort() => RandomNumberGenerator.GetHexString(32, lowercase: true);

        public static bool Validate(string? secret)
        {
            if (string.IsNullOrEmpty(secret)) return false;

            try
            {
                var bytes = Convert.FromHexString(secret);
                return secret.Length is 32 or 64;
            }
            catch
            {
                return false;
            }
        }
    }
}
