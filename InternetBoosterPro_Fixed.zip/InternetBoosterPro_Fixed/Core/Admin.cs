using System;
using System.Diagnostics;
using System.Security.Principal;

namespace InternetBoosterPro.Core
{
    /// <summary>
    /// Проверка и (пере)запуск с правами администратора. Аналог core/admin.py.
    /// </summary>
    public static class Admin
    {
        public static bool IsAdmin()
        {
            if (!OperatingSystem.IsWindows())
                return true;

            try
            {
                using var identity = WindowsIdentity.GetCurrent();
                var principal = new WindowsPrincipal(identity);
                return principal.IsInRole(WindowsBuiltInRole.Administrator);
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Перезапускает приложение с правами администратора, если это ещё не сделано.
        /// </summary>
        public static bool RequireAdmin()
        {
            if (IsAdmin())
                return true;

            if (!OperatingSystem.IsWindows())
                return false;

            try
            {
                var exePath = Environment.ProcessPath ?? Process.GetCurrentProcess().MainModule?.FileName;

                if (string.IsNullOrEmpty(exePath))
                    return false;

                var startInfo = new ProcessStartInfo
                {
                    FileName = exePath,
                    UseShellExecute = true,
                    Verb = "runas",
                };

                Process.Start(startInfo);
            }
            catch
            {
                // пользователь мог отменить UAC-запрос - не считаем это фатальной ошибкой
            }

            return false;
        }
    }
}
