using System.Diagnostics;

namespace InternetBoosterPro.Core
{
    /// <summary>
    /// Игровой режим: повышает приоритет текущего процесса. Аналог core/core_gaming.py.
    /// </summary>
    public class GamingMode
    {
        public static readonly GamingMode Instance = new();

        public bool Enabled { get; private set; }

        public void Enable()
        {
            if (Enabled) return;

            Enabled = true;
            Logger.Log("Gaming Mode включён");
            OptimizeProcesses();
        }

        public void Disable()
        {
            if (!Enabled) return;

            Enabled = false;

            try
            {
                Process.GetCurrentProcess().PriorityClass = ProcessPriorityClass.Normal;
            }
            catch
            {
                // может не хватать прав - не критично
            }

            Logger.Log("Gaming Mode выключен");
        }

        public void OptimizeProcesses()
        {
            try
            {
                Process.GetCurrentProcess().PriorityClass = ProcessPriorityClass.High;
                Logger.Log("Приоритет приложения повышен");
            }
            catch
            {
                // может не хватать прав - не критично
            }
        }
    }
}
