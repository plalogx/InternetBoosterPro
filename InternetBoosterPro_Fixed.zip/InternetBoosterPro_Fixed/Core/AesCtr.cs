using System;
using System.Security.Cryptography;

namespace InternetBoosterPro.Core
{
    /// <summary>
    /// AES-256 в режиме CTR со 128-битным счётчиком (big-endian), полностью
    /// совместимый по поведению с Python cryptography.hazmat Cipher(AES, CTR(iv)):
    /// keystream = AES_ECB(counter++) XOR data, счётчик - это сам IV,
    /// инкрементируемый как 128-битное целое после каждого блока.
    ///
    /// Поддерживает потоковый Update(), сохраняя состояние между вызовами -
    /// это важно, т.к. в MTProto-протоколе шифрование/дешифрование "нарастает"
    /// по мере поступления новых кусков (chunks) трафика.
    /// </summary>
    public sealed class AesCtr : IDisposable
    {
        private readonly Aes _aes;
        private readonly byte[] _counter;
        private readonly byte[] _keystream = new byte[16];
        private int _keystreamPos = 16; // 16 = "буфер пуст, нужно сгенерировать новый блок"

        public AesCtr(byte[] key, byte[] iv)
        {
            if (key.Length != 32) throw new ArgumentException("AES-256 требует 32-байтный ключ");
            if (iv.Length != 16) throw new ArgumentException("IV/counter должен быть 16 байт");

            _aes = Aes.Create();
            _aes.Key = key;
            _aes.Mode = CipherMode.ECB;
            _aes.Padding = PaddingMode.None;

            _counter = (byte[])iv.Clone();
        }

        /// <summary>Шифрует/дешифрует (XOR симметричен) очередной блок данных.</summary>
        public byte[] Update(byte[] data)
        {
            var result = new byte[data.Length];

            using var encryptor = _aes.CreateEncryptor();

            for (var i = 0; i < data.Length; i++)
            {
                if (_keystreamPos >= 16)
                {
                    encryptor.TransformBlock(_counter, 0, 16, _keystream, 0);
                    IncrementCounter();
                    _keystreamPos = 0;
                }

                result[i] = (byte)(data[i] ^ _keystream[_keystreamPos]);
                _keystreamPos++;
            }

            return result;
        }

        private void IncrementCounter()
        {
            // 128-битное big-endian целое, инкремент с переносом (как у Python cryptography)
            for (var i = 15; i >= 0; i--)
            {
                _counter[i]++;
                if (_counter[i] != 0) break;
            }
        }

        public void Dispose() => _aes.Dispose();
    }
}
