using System;
using System.Diagnostics;

namespace InternetBoosterPro.Core
{
    /// <summary>
    /// Оптимизация и сброс TCP-параметров. Аналог core/tcp.py.
    /// </summary>
    public static class TcpTools
    {
        public static string RunCommand(string command)
        {
            try
            {
                var psi = new ProcessStartInfo
                {
                    FileName = "cmd.exe",
                    Arguments = $"/c {command}",
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                };

                using var process = Process.Start(psi);
                if (process == null) return "";

                var output = process.StandardOutput.ReadToEnd();
                process.WaitForExit(30_000);
                return output;
            }
            catch (Exception error)
            {
                Logger.Log(error.Message);
                return "";
            }
        }

        public static bool OptimizeTcp()
        {
            string[] commands =
            {
                "netsh int tcp set global autotuninglevel=normal",
                "netsh int tcp set global rss=enabled",
                "netsh int tcp set global chimney=enabled",
                "netsh int tcp set global ecncapability=disabled",
            };

            foreach (var cmd in commands)
            {
                RunCommand(cmd);
                Logger.Log($"TCP: {cmd}");
            }

            return true;
        }

        public static void ResetTcp()
        {
            string[] commands =
            {
                "netsh int tcp reset",
                "netsh winsock reset",
            };

            foreach (var cmd in commands)
                RunCommand(cmd);

            Logger.Log("TCP настройки сброшены");
        }
    }
}
