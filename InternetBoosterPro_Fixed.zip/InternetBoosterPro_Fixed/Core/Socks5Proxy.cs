using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace InternetBoosterPro.Core
{
    /// <summary>
    /// Простой SOCKS5-прокси сервер (RFC 1928). Аналог core/socks5_proxy.py —
    /// см. подробное описание протокола там.
    /// </summary>
    public class Socks5Error : Exception
    {
        public Socks5Error(string message) : base(message) { }
    }

    public class Socks5Stats
    {
        public int TotalConnections;
        public int ActiveConnections;
    }

    public class Socks5ProxyServer
    {
        private const byte SocksVersion = 0x05;

        private const byte MethodNoAuth = 0x00;
        private const byte MethodUserPass = 0x02;
        private const byte MethodNoneAcceptable = 0xFF;

        private const byte CmdConnect = 0x01;

        private const byte AtypIpv4 = 0x01;
        private const byte AtypDomain = 0x03;
        private const byte AtypIpv6 = 0x04;

        public string Host { get; }
        public int Port { get; }
        public string Username { get; }
        public string Password { get; }
        public bool AuthRequired { get; }
        public bool UseWarp { get; }
        public Action<string> OnLog { get; }
        public Socks5Stats Stats { get; } = new();

        private readonly WarpManager? _warp;
        private TcpListener? _listener;
        private CancellationTokenSource? _cts;
        private Task? _serveTask;

        public Socks5ProxyServer(string host, int port, string? username = null, string? password = null,
            bool useWarp = false, Action<string>? onLog = null)
        {
            Host = host;
            Port = port;
            Username = (username ?? "").Trim();
            Password = password ?? "";
            AuthRequired = Username.Length > 0;
            UseWarp = useWarp;
            _warp = useWarp ? new WarpManager() : null;
            OnLog = onLog ?? (msg => Logger.Log($"[SOCKS5] {msg}"));
        }

        public bool IsRunning => _serveTask != null && !_serveTask.IsCompleted;

        public void Start()
        {
            if (IsRunning) return;

            _cts = new CancellationTokenSource();
            _serveTask = Task.Run(() => RunAsync(_cts.Token));
        }

        public void Stop()
        {
            try { _cts?.Cancel(); } catch { /* ignore */ }
            try { _listener?.Stop(); } catch { /* ignore */ }

            _serveTask = null;
        }

        private async Task RunAsync(CancellationToken token)
        {
            if (UseWarp && _warp != null)
                _warp.EnsureConnected(10, OnLog);

            await ServeAsync(token);
        }

        private async Task ServeAsync(CancellationToken token)
        {
            var bindAddress = Host == "0.0.0.0" ? IPAddress.Any : IPAddress.Parse(Host);

            try
            {
                _listener = new TcpListener(bindAddress, Port);
                _listener.Start();
            }
            catch (Exception error)
            {
                OnLog($"Не удалось запустить SOCKS5 на {Host}:{Port} — {error.Message}");
                return;
            }

            OnLog($"SOCKS5 прокси запущен на {Host}:{Port} (авторизация: {(AuthRequired ? "да" : "нет")})");

            try
            {
                while (!token.IsCancellationRequested)
                {
                    TcpClient client;

                    try
                    {
                        client = await _listener.AcceptTcpClientAsync(token);
                    }
                    catch (OperationCanceledException)
                    {
                        break;
                    }
                    catch (ObjectDisposedException)
                    {
                        break;
                    }

                    _ = Task.Run(() => HandleClientAsync(client, token), token);
                }
            }
            catch (Exception error)
            {
                OnLog($"Прокси остановлен с ошибкой: {error.Message}");
            }
        }

        private async Task HandleClientAsync(TcpClient client, CancellationToken token)
        {
            var peer = client.Client.RemoteEndPoint?.ToString() ?? "unknown";
            Interlocked.Increment(ref Stats.TotalConnections);
            Interlocked.Increment(ref Stats.ActiveConnections);

            try
            {
                await NegotiateAndConnectAsync(client, token);
            }
            catch (Socks5Error error)
            {
                OnLog($"Отклонено соединение {peer}: {error.Message}");
            }
            catch (EndOfStreamException)
            {
                OnLog($"Соединение {peer} оборвалось до завершения handshake");
            }
            catch (IOException)
            {
                OnLog($"Соединение {peer} оборвалось до завершения handshake");
            }
            catch (Exception error)
            {
                OnLog($"Ошибка соединения {peer}: {error.Message}");
            }
            finally
            {
                Interlocked.Decrement(ref Stats.ActiveConnections);
            }
        }

        private async Task NegotiateAndConnectAsync(TcpClient client, CancellationToken token)
        {
            var peer = client.Client.RemoteEndPoint?.ToString() ?? "unknown";
            var stream = client.GetStream();

            // --- 1. Приветствие клиента: VER, NMETHODS, METHODS[NMETHODS] ---
            var header = new byte[2];
            await stream.ReadExactlyAsync(header, token);
            byte version = header[0], nmethods = header[1];

            if (version != SocksVersion)
            {
                client.Close();
                throw new Socks5Error($"неверная версия SOCKS: {version}");
            }

            var methods = new byte[nmethods];
            if (nmethods > 0)
                await stream.ReadExactlyAsync(methods, token);

            byte chosen;

            if (AuthRequired)
                chosen = methods.Contains(MethodUserPass) ? MethodUserPass : MethodNoneAcceptable;
            else
                chosen = methods.Contains(MethodNoAuth) ? MethodNoAuth : MethodNoneAcceptable;

            await stream.WriteAsync(new[] { SocksVersion, chosen }, token);
            await stream.FlushAsync(token);

            if (chosen == MethodNoneAcceptable)
            {
                client.Close();
                throw new Socks5Error("клиент не предложил приемлемый метод авторизации");
            }

            // --- 2. Логин/пароль (RFC 1929), если требуется ---
            if (chosen == MethodUserPass)
            {
                var authHeader = new byte[2];
                await stream.ReadExactlyAsync(authHeader, token);
                var ulen = authHeader[1];

                var unameBytes = new byte[ulen];
                await stream.ReadExactlyAsync(unameBytes, token);
                var uname = Encoding.UTF8.GetString(unameBytes);

                var plenBuf = new byte[1];
                await stream.ReadExactlyAsync(plenBuf, token);
                var plen = plenBuf[0];

                var passBytes = new byte[plen];
                await stream.ReadExactlyAsync(passBytes, token);
                var passwd = Encoding.UTF8.GetString(passBytes);

                var ok = uname == Username && passwd == Password;
                await stream.WriteAsync(new byte[] { 0x01, (byte)(ok ? 0x00 : 0x01) }, token);
                await stream.FlushAsync(token);

                if (!ok)
                {
                    client.Close();
                    throw new Socks5Error($"неверный логин/пароль от {peer}");
                }
            }

            // --- 3. Запрос клиента: VER, CMD, RSV, ATYP, DST.ADDR, DST.PORT ---
            var reqHeader = new byte[4];
            await stream.ReadExactlyAsync(reqHeader, token);
            var reqVersion = reqHeader[0];
            var cmd = reqHeader[1];
            var atyp = reqHeader[3];

            if (reqVersion != SocksVersion)
                throw new Socks5Error("неверная версия SOCKS в запросе");

            string dstAddr;

            if (atyp == AtypIpv4)
            {
                var addrBytes = new byte[4];
                await stream.ReadExactlyAsync(addrBytes, token);
                dstAddr = string.Join(".", addrBytes);
            }
            else if (atyp == AtypDomain)
            {
                var lenBuf = new byte[1];
                await stream.ReadExactlyAsync(lenBuf, token);
                var domainBytes = new byte[lenBuf[0]];
                await stream.ReadExactlyAsync(domainBytes, token);
                dstAddr = Encoding.ASCII.GetString(domainBytes);
            }
            else if (atyp == AtypIpv6)
            {
                var addrBytes = new byte[16];
                await stream.ReadExactlyAsync(addrBytes, token);
                dstAddr = string.Join(":", Enumerable.Range(0, 8)
                    .Select(i => Convert.ToHexString(addrBytes, i * 2, 2).ToLowerInvariant()));
            }
            else
            {
                await SendReplyAsync(stream, 0x08, token: token); // address type not supported
                throw new Socks5Error($"неизвестный тип адреса ATYP={atyp}");
            }

            var portBuf = new byte[2];
            await stream.ReadExactlyAsync(portBuf, token);
            if (BitConverter.IsLittleEndian) Array.Reverse(portBuf);
            var dstPort = BitConverter.ToUInt16(portBuf, 0);

            if (cmd != CmdConnect)
            {
                await SendReplyAsync(stream, 0x07, token: token); // command not supported
                throw new Socks5Error($"поддерживается только CONNECT, получено CMD={cmd}");
            }

            // --- 4. Подключаемся к реальному адресу назначения ---
            TcpClient remoteClient;

            try
            {
                remoteClient = new TcpClient();
                await remoteClient.ConnectAsync(dstAddr, dstPort, token);
            }
            catch (Exception error)
            {
                await SendReplyAsync(stream, 0x05, token: token); // connection refused
                OnLog($"Не удалось подключиться к {dstAddr}:{dstPort}: {error.Message}");
                return;
            }

            var localEndpoint = (IPEndPoint?)remoteClient.Client.LocalEndPoint;
            var bindHost = localEndpoint?.Address.ToString() ?? "0.0.0.0";
            var bindPort = (ushort)(localEndpoint?.Port ?? 0);

            await SendReplyAsync(stream, 0x00, bindHost, bindPort, token);

            OnLog($"{peer} → {dstAddr}:{dstPort} — туннель установлен");

            var remoteStream = remoteClient.GetStream();

            _ = Task.Run(() => PipeAsync(stream, remoteStream, token), token);
            _ = Task.Run(() => PipeAsync(remoteStream, stream, token), token);
        }

        private static async Task SendReplyAsync(NetworkStream stream, byte repCode, string bindHost = "0.0.0.0",
            ushort bindPort = 0, CancellationToken token = default)
        {
            byte[] addrBytes;

            try
            {
                addrBytes = bindHost.Split('.').Select(p => (byte)int.Parse(p)).ToArray();
                if (addrBytes.Length != 4) throw new FormatException();
            }
            catch
            {
                addrBytes = new byte[] { 0, 0, 0, 0 };
            }

            var portBytes = BitConverter.GetBytes(bindPort);
            if (BitConverter.IsLittleEndian) Array.Reverse(portBytes);

            var reply = new byte[4 + addrBytes.Length + 2];
            reply[0] = SocksVersion;
            reply[1] = repCode;
            reply[2] = 0x00;
            reply[3] = AtypIpv4;
            addrBytes.CopyTo(reply, 4);
            portBytes.CopyTo(reply, 4 + addrBytes.Length);

            await stream.WriteAsync(reply, token);
            await stream.FlushAsync(token);
        }

        private static async Task PipeAsync(NetworkStream reader, NetworkStream writer, CancellationToken token)
        {
            var buffer = new byte[16384];

            try
            {
                while (true)
                {
                    var n = await reader.ReadAsync(buffer, token);
                    if (n == 0) break;

                    await writer.WriteAsync(buffer.AsMemory(0, n), token);
                    await writer.FlushAsync(token);
                }
            }
            catch (IOException) { /* соединение оборвалось */ }
            catch (OperationCanceledException) { /* остановка сервера */ }
            catch (ObjectDisposedException) { /* поток уже закрыт */ }
            finally
            {
                try { writer.Close(); } catch { /* ignore */ }
            }
        }
    }
}
