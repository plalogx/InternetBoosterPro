using System.Collections.Generic;
using System.Diagnostics;

namespace InternetBoosterPro.Core
{
    /// <summary>
    /// Управление DNS сетевого адаптера через netsh. Аналог core/dns.py.
    /// </summary>
    public static class DnsManager
    {
        public static readonly Dictionary<string, (string Primary, string? Secondary)> DnsList = new()
        {
            ["Cloudflare"] = ("1.1.1.1", "1.0.0.1"),
            ["Google"] = ("8.8.8.8", "8.8.4.4"),
            ["Dns.SB"] = ("185.222.222.222", "185.222.220.220"),
            ["Quad9"] = ("9.9.9.9", "149.112.112.112"),
            ["AdGuard"] = ("94.140.14.14", "94.140.15.15"),
            ["OpenDNS"] = ("208.67.222.222", "208.67.220.220"),
            ["dnsdoh.art"] = ("194.180.189.33", null),
            ["Xbox DNS"] = ("111.88.96.50", null),
            ["Xbox DNS v2"] = ("87.228.47.200", null),
            ["Xbox DNS (old)"] = ("176.99.11.77", null),
            ["Comss DNS"] = ("83.220.169.155", null),
            ["dns.malw.link"] = ("84.21.189.133", null),
        };

        private static void RunShell(string command)
        {
            try
            {
                var psi = new ProcessStartInfo
                {
                    FileName = "cmd.exe",
                    Arguments = $"/c {command}",
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                };

                using var process = Process.Start(psi);
                process?.WaitForExit(15_000);
            }
            catch
            {
                // ошибки конкретной команды не должны прерывать выполнение остальных
            }
        }

        public static bool SetDns(string name)
        {
            var adapter = Adapter.GetActiveAdapter();

            if (adapter == null)
            {
                Logger.Log("Адаптер не найден");
                return false;
            }

            if (!DnsList.TryGetValue(name, out var pair))
                return false;

            RunShell($"netsh interface ip set dns name=\"{adapter}\" static {pair.Primary}");

            if (!string.IsNullOrWhiteSpace(pair.Secondary) && pair.Secondary != pair.Primary)
            {
                RunShell($"netsh interface ip add dns name=\"{adapter}\" {pair.Secondary} index=2");
            }

            Logger.Log($"DNS {name} установлен на {adapter}");
            return true;
        }

        public static bool ResetDns()
        {
            var adapter = Adapter.GetActiveAdapter();

            if (adapter == null)
            {
                Logger.Log("Адаптер не найден");
                return false;
            }

            RunShell($"netsh interface ip set dns name=\"{adapter}\" dhcp");

            Logger.Log($"DNS адаптера {adapter} возвращён на автоматический (DHCP)");
            return true;
        }
    }
}
