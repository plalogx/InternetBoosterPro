using System;

namespace InternetBoosterPro.Core
{
    /// <summary>
    /// Показ системных уведомлений Windows. Аналог core/notifier.py.
    /// Использует балун трей-иконки (см. Tray/TrayIconManager.cs); если трей ещё
    /// не создан, безопасно пишет в лог, как и оригинал при недоступности winotify.
    /// </summary>
    public static class Notifier
    {
        /// <summary>
        /// Устанавливается из Tray.TrayIconManager после создания иконки в трее.
        /// </summary>
        public static Action<string, string>? ShowBalloon;

        public static void Notify(string title, string message)
        {
            if (ShowBalloon == null)
            {
                Logger.Log($"[уведомление] {title}: {message}");
                return;
            }

            try
            {
                ShowBalloon(title, message);
            }
            catch (Exception error)
            {
                Logger.Log($"Ошибка показа уведомления: {error.Message}");
            }
        }
    }
}
