using System;
using System.Timers;
using Timer = System.Timers.Timer;

namespace InternetBoosterPro.Core
{
    /// <summary>
    /// Автоматически очищает сетевые параметры каждые N минут ("по кулдауну").
    /// Аналог core/scheduler.py (там использовался QTimer - здесь System.Timers.Timer;
    /// события Tick/Optimized нужно подписывать из UI-потока и мигрировать через Dispatcher).
    /// </summary>
    public class AutoOptimizer
    {
        public static readonly AutoOptimizer Instance = new();

        public event Action<int>? Tick;       // сколько секунд осталось до следующей очистки
        public event Action? Optimized;       // сигнал о том, что автоочистка выполнена

        public int IntervalMinutes { get; private set; } = 10;
        public bool Notifications { get; private set; } = true;
        public int SecondsLeft { get; private set; }
        public bool Enabled { get; private set; }

        private readonly Timer _timer;

        private AutoOptimizer()
        {
            SecondsLeft = IntervalMinutes * 60;

            _timer = new Timer(1000);
            _timer.Elapsed += OnTick;
        }

        public void SetInterval(int minutes)
        {
            IntervalMinutes = Math.Max(1, minutes);
            SecondsLeft = IntervalMinutes * 60;
        }

        public void SetNotifications(bool value) => Notifications = value;

        public void Start()
        {
            if (Enabled) return;

            Enabled = true;
            SecondsLeft = IntervalMinutes * 60;
            _timer.Start();

            Logger.Log($"Автоочистка по КД включена (интервал: {IntervalMinutes} мин.)");
        }

        public void Stop()
        {
            Enabled = false;
            _timer.Stop();

            Logger.Log("Автоочистка по КД выключена");
        }

        /// <summary>Выполняет очистку немедленно и сбрасывает таймер кулдауна.</summary>
        public void RunNow()
        {
            Optimizer.QuickClean();
            Optimized?.Invoke();

            if (Notifications)
            {
                Notifier.Notify("InternetBooster Pro", "Сетевые параметры автоматически очищены");
            }

            SecondsLeft = IntervalMinutes * 60;
        }

        private void OnTick(object? sender, ElapsedEventArgs e)
        {
            SecondsLeft -= 1;
            Tick?.Invoke(SecondsLeft);

            if (SecondsLeft <= 0)
                RunNow();
        }
    }
}
