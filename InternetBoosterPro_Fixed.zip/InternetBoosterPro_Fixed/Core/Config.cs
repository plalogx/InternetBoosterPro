using System;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace InternetBoosterPro.Core
{
    public class MtprotoConfig
    {
        [JsonPropertyName("ip")] public string Ip { get; set; } = "0.0.0.0";
        [JsonPropertyName("public_ip")] public string PublicIp { get; set; } = "";
        [JsonPropertyName("port")] public int Port { get; set; } = 8443;
        [JsonPropertyName("secret")] public string Secret { get; set; } = "";
        [JsonPropertyName("dcs_text")] public string DcsText { get; set; } = "";
        [JsonPropertyName("cf_enabled")] public bool CfEnabled { get; set; } = false;
    }

    public class Socks5Config
    {
        [JsonPropertyName("ip")] public string Ip { get; set; } = "0.0.0.0";
        [JsonPropertyName("public_ip")] public string PublicIp { get; set; } = "";
        [JsonPropertyName("port")] public int Port { get; set; } = 1080;
        [JsonPropertyName("auth_enabled")] public bool AuthEnabled { get; set; } = false;
        [JsonPropertyName("username")] public string Username { get; set; } = "";
        [JsonPropertyName("password")] public string Password { get; set; } = "";
        [JsonPropertyName("use_warp")] public bool UseWarp { get; set; } = false;
    }

    public class AppConfig
    {
        [JsonPropertyName("autorun")] public bool Autorun { get; set; } = false;
        [JsonPropertyName("notifications")] public bool Notifications { get; set; } = true;
        [JsonPropertyName("interval")] public int Interval { get; set; } = 10;
        [JsonPropertyName("dns")] public string Dns { get; set; } = "Google";
        [JsonPropertyName("auto_optimize")] public bool AutoOptimize { get; set; } = false;
        [JsonPropertyName("gaming_mode")] public bool GamingMode { get; set; } = false;
        [JsonPropertyName("mtproto")] public MtprotoConfig Mtproto { get; set; } = new();
        [JsonPropertyName("socks5")] public Socks5Config Socks5 { get; set; } = new();
    }

    /// <summary>
    /// Загрузка/сохранение config.json. Аналог core/config.py.
    /// </summary>
    public static class ConfigManager
    {
        private const string ConfigFile = "config.json";

        private static readonly JsonSerializerOptions JsonOptions = new()
        {
            WriteIndented = true,
            Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
        };

        public static AppConfig Load()
        {
            if (!File.Exists(ConfigFile))
            {
                var fresh = new AppConfig();
                Save(fresh);
                return fresh;
            }

            try
            {
                var json = File.ReadAllText(ConfigFile, System.Text.Encoding.UTF8);
                var loaded = JsonSerializer.Deserialize<AppConfig>(json, JsonOptions);
                return loaded ?? new AppConfig();
            }
            catch (Exception error)
            {
                Logger.Log($"Ошибка чтения config.json: {error.Message}");
                return new AppConfig();
            }
        }

        public static bool Save(AppConfig config)
        {
            try
            {
                var json = JsonSerializer.Serialize(config, JsonOptions);
                File.WriteAllText(ConfigFile, json, System.Text.Encoding.UTF8);
                return true;
            }
            catch (Exception error)
            {
                Logger.Log($"Ошибка сохранения config.json: {error.Message}");
                return false;
            }
        }
    }
}
