using System;
using Microsoft.Win32;

namespace InternetBoosterPro.Core
{
    /// <summary>
    /// Управление автозапуском приложения вместе с Windows через реестр.
    /// Аналог core/startup.py.
    /// </summary>
    public static class Startup
    {
        private const string AppName = "InternetBoosterPro";
        private const string RegPath = @"Software\Microsoft\Windows\CurrentVersion\Run";

        private static string GetLaunchCommand()
        {
            var exePath = Environment.ProcessPath ?? System.Diagnostics.Process.GetCurrentProcess().MainModule?.FileName ?? "";
            return $"\"{exePath}\"";
        }

        public static bool EnableStartup()
        {
            try
            {
                using var key = Registry.CurrentUser.OpenSubKey(RegPath, writable: true);
                key?.SetValue(AppName, GetLaunchCommand());

                Logger.Log("Автозапуск с Windows включён");
                return true;
            }
            catch (Exception error)
            {
                Logger.Log($"Ошибка включения автозапуска: {error.Message}");
                return false;
            }
        }

        public static bool DisableStartup()
        {
            try
            {
                using var key = Registry.CurrentUser.OpenSubKey(RegPath, writable: true);
                key?.DeleteValue(AppName, throwOnMissingValue: false);

                Logger.Log("Автозапуск с Windows выключен");
                return true;
            }
            catch (Exception error)
            {
                Logger.Log($"Ошибка отключения автозапуска: {error.Message}");
                return false;
            }
        }

        public static bool IsStartupEnabled()
        {
            try
            {
                using var key = Registry.CurrentUser.OpenSubKey(RegPath, writable: false);
                return key?.GetValue(AppName) != null;
            }
            catch
            {
                return false;
            }
        }
    }
}
