using System;
using System.Net.Sockets;
using System.Security.Cryptography;

namespace InternetBoosterPro.Core
{
    /// <summary>
    /// Диагностика MTProto-прокси: подключается к СОБСТВЕННОМУ прокси как настоящий
    /// Telegram-клиент (строит handshake по тому же алгоритму), отправляет минимальный
    /// валидный MTProto-запрос (req_pq_multi) и смотрит, придёт ли осмысленный ответ.
    /// Аналог core/mtproto_selftest.py — см. подробное описание там.
    /// </summary>
    public static class MtprotoSelftest
    {
        private const uint ReqPqMulti = 0xBE7E8EF1;

        private static (byte[] Header, AesCtr Encryptor, AesCtr Decryptor) BuildHandshake(byte[] secret, int dcNum = 2)
        {
            byte[] header;

            while (true)
            {
                header = RandomNumberGenerator.GetBytes(64);

                var firstInt = BitConverter.ToUInt32(header, 0);
                var secondInt = BitConverter.ToUInt32(header, 4);

                if (header[0] != 0xEF && !MtprotoConstants.BadFirstInts.Contains(firstInt) && secondInt != 0)
                    break;
            }

            var decryptKeyRaw = header[8..40];
            var decryptIv = header[40..56];

            var reversedHeader = new byte[48];
            for (var i = 0; i < 48; i++)
                reversedHeader[i] = header[55 - i];

            var encryptKeyRaw = reversedHeader[0..32];
            var encryptIv = reversedHeader[32..48];

            // с точки зрения КЛИЕНТА: "encrypt" строится из тех же байт, что сервер
            // использует как decrypt-ключ, и наоборот
            var clientEncryptKey = SHA256.HashData(MtProxyServer.Concat(decryptKeyRaw, secret));
            var clientDecryptKey = SHA256.HashData(MtProxyServer.Concat(encryptKeyRaw, secret));

            var encryptor = new AesCtr(clientEncryptKey, decryptIv);
            var decryptor = new AesCtr(clientDecryptKey, encryptIv);

            // "сжигаем" keystream дешифратора на 64 байта - симметрично тому,
            // что сервер делает и с encryptor, и с decryptor на этапе handshake
            decryptor.Update(new byte[64]);

            var raw = (byte[])header.Clone();
            Array.Copy(MtprotoConstants.TagIntermediate, 0, raw, 56, 4);

            var dcNumBytes = BitConverter.GetBytes((short)dcNum);
            Array.Copy(dcNumBytes, 0, raw, 60, 2);

            var encrypted = encryptor.Update(raw);

            var sentHeader = new byte[64];
            Array.Copy(raw, 0, sentHeader, 0, 56);
            Array.Copy(encrypted, 56, sentHeader, 56, 8);

            return (sentHeader, encryptor, decryptor);
        }

        private static byte[] BuildReqPqFrame()
        {
            var authKeyId = new byte[8];
            var messageId = BitConverter.GetBytes((long)(DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() / 1000.0 * Math.Pow(2, 32)) & ~0x3L);
            var nonce = RandomNumberGenerator.GetBytes(16);
            var body = new byte[4 + 16];
            BitConverter.GetBytes(ReqPqMulti).CopyTo(body, 0);
            nonce.CopyTo(body, 4);

            var messageLength = BitConverter.GetBytes(body.Length);

            var plainMsg = new byte[authKeyId.Length + messageId.Length + messageLength.Length + body.Length];
            var offset = 0;
            authKeyId.CopyTo(plainMsg, offset); offset += authKeyId.Length;
            messageId.CopyTo(plainMsg, offset); offset += messageId.Length;
            messageLength.CopyTo(plainMsg, offset); offset += messageLength.Length;
            body.CopyTo(plainMsg, offset);

            var frame = new byte[4 + plainMsg.Length];
            BitConverter.GetBytes(plainMsg.Length).CopyTo(frame, 0);
            plainMsg.CopyTo(frame, 4);

            return frame;
        }

        /// <summary>Возвращает (ok, details).</summary>
        public static (bool Ok, string Details) RunSelftest(string host, int port, string secretHex, int timeoutSeconds = 8, Action<string>? log = null)
        {
            var logFn = log ?? (_ => { });
            var secret = Convert.FromHexString(secretHex);

            var connectHost = (host is "0.0.0.0" or "::" or "") ? "127.0.0.1" : host;

            logFn($"[Selftest] Подключаюсь к прокси {connectHost}:{port}...");

            using var socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            socket.ReceiveTimeout = timeoutSeconds * 1000;
            socket.SendTimeout = timeoutSeconds * 1000;

            try
            {
                var connectTask = socket.ConnectAsync(connectHost, port);
                if (!connectTask.Wait(timeoutSeconds * 1000))
                    return (false, $"Не удалось подключиться к прокси на {connectHost}:{port} — таймаут. Прокси запущен?");
            }
            catch (Exception error)
            {
                return (false, $"Не удалось подключиться к прокси на {connectHost}:{port} — {error.Message}. Прокси запущен?");
            }

            try
            {
                var (header, encryptor, decryptor) = BuildHandshake(secret);

                logFn("[Selftest] Отправляю handshake (как настоящий клиент)...");
                socket.Send(header);

                var frame = BuildReqPqFrame();
                logFn("[Selftest] Отправляю req_pq_multi через датацентр...");
                socket.Send(encryptor.Update(frame));

                logFn("[Selftest] Жду ответ от датацентра Telegram...");

                var buffer = new byte[4096];
                int received;

                try
                {
                    received = socket.Receive(buffer);
                }
                catch (SocketException)
                {
                    return (false,
                        $"Handshake отправлен, но ответа НЕ пришло за {timeoutSeconds} сек. Скорее всего прокси " +
                        "не смог подключиться к датацентру Telegram (проверьте IP датацентров и интернет на " +
                        "сервере), либо связь до Telegram заблокирована.");
                }

                if (received == 0)
                {
                    return (false,
                        "Прокси принял handshake, но сразу закрыл соединение. Смотрите logs/app.log — там должна " +
                        "быть причина (неверный secret, неизвестный тег протокола, ошибка подключения к датацентру).");
                }

                var raw = buffer[..received];
                var decrypted = decryptor.Update(raw);
                var length = decrypted.Length >= 4 ? BitConverter.ToInt32(decrypted, 0) : -1;

                logFn($"[Selftest] Получено {received} байт, расшифрованная длина кадра: {length}");

                if (length is > 0 and <= 65536)
                {
                    return (true,
                        $"Успех! Прокси корректно передал запрос в датацентр Telegram и вернул осмысленный ответ " +
                        $"({received} байт). Цепочка клиент → прокси → Telegram работает.\n\n" +
                        "Если настоящий Telegram всё равно не подключается — проблема почти наверняка в проброс " +
                        "порта на роутере или в неверном публичном IP в ссылке, а не в самом прокси.");
                }

                return (false,
                    $"Ответ получен ({received} байт), но после расшифровки он не похож на валидный MTProto-кадр. " +
                    "Возможно, реализация протокола (ключи/смещения) не совпадает с тем, что ожидает настоящий " +
                    "клиент Telegram.");
            }
            catch (Exception error)
            {
                return (false, $"Ошибка во время самотеста: {error.Message}");
            }
            finally
            {
                try { socket.Close(); } catch { /* ignore */ }
            }
        }
    }
}
