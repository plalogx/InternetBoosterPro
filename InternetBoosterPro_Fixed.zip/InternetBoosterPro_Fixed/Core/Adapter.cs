using System.Linq;
using System.Net.NetworkInformation;

namespace InternetBoosterPro.Core
{
    /// <summary>
    /// Определение активного сетевого адаптера. Аналог core/adapter.py.
    /// </summary>
    public static class Adapter
    {
        public static string? GetActiveAdapter()
        {
            var active = NetworkInterface.GetAllNetworkInterfaces()
                .FirstOrDefault(nic =>
                    nic.OperationalStatus == OperationalStatus.Up &&
                    nic.NetworkInterfaceType != NetworkInterfaceType.Loopback);

            if (active != null)
            {
                Logger.Log($"Активный адаптер: {active.Name}");
                return active.Name;
            }

            return null;
        }
    }
}
