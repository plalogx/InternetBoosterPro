using System;
using System.Threading;

namespace InternetBoosterPro.Core
{
    /// <summary>
    /// Собирает метрики сети в фоновых потоках, чтобы интерфейс не подвисал.
    /// Аналог core/background.py.
    /// </summary>
    public class Background
    {
        public static readonly Background Instance = new();

        public bool Running { get; private set; } = true;

        public string? Adapter { get; private set; }
        public string PacketLoss { get; private set; } = "0%";
        public double Download { get; private set; }
        public double Upload { get; private set; }

        public void Start()
        {
            new Thread(AdapterLoop) { IsBackground = true }.Start();
            new Thread(SpeedLoop) { IsBackground = true }.Start();
            new Thread(LossLoop) { IsBackground = true }.Start();
        }

        private void AdapterLoop()
        {
            while (Running)
            {
                Adapter = Core.Adapter.GetActiveAdapter();
                Thread.Sleep(10_000);
            }
        }

        private void SpeedLoop()
        {
            while (Running)
            {
                try
                {
                    var result = NetworkMonitor.Instance.SpeedTest();
                    Download = result.Download;
                    Upload = result.Upload;
                }
                catch (Exception error)
                {
                    Logger.Log($"Ошибка замера скорости: {error.Message}");
                }

                Thread.Sleep(4_000);
            }
        }

        private void LossLoop()
        {
            while (Running)
            {
                try
                {
                    PacketLoss = NetworkMonitor.Instance.PacketLoss();
                }
                catch (Exception error)
                {
                    Logger.Log($"Ошибка замера потерь пакетов: {error.Message}");
                }

                Thread.Sleep(30_000);
            }
        }
    }
}
