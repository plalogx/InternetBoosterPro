using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace InternetBoosterPro.Core
{
    /// <summary>
    /// Лёгкий MTProto-прокси сервер (протокол obfuscated2 / intermediate),
    /// совместимый с секретами формата MTProtoSecret (32 hex-символа).
    /// Аналог core/mtproto_proxy.py — см. подробное описание протокола там.
    /// </summary>
    public class MtProxyStats
    {
        public int TotalConnections;
        public int ActiveConnections;
    }

    public class ClientHandshakeException : Exception
    {
        public ClientHandshakeException(string message) : base(message) { }
    }

    public static class MtprotoConstants
    {
        public const int HandshakeLen = 64;
        public const int DcPort = 443;

        public static readonly byte[] TagAbridged = { 0xef, 0xef, 0xef, 0xef };
        public static readonly byte[] TagIntermediate = { 0xee, 0xee, 0xee, 0xee };
        public static readonly byte[] TagPaddedIntermediate = { 0xdd, 0xdd, 0xdd, 0xdd };

        public static readonly HashSet<uint> BadFirstInts = new()
        {
            0x44414548, // 'HEAD'
            0x54534F50, // 'POST'
            0x20544547, // 'GET '
            0x4954504F, // 'OPTI'
            0xDDDDDDDD,
            0xEEEEEEEE,
            0x0A0A0A0A,
        };

        public static readonly Dictionary<int, string> DefaultDcs = new()
        {
            [1] = "149.154.175.53",
            [2] = "149.154.167.51",
            [3] = "149.154.175.100",
            [4] = "149.154.167.91",
            [5] = "91.108.56.130",
        };

        /// <summary>Парсит текст вида '2:149.154.167.51' построчно в dict {num: ip}.</summary>
        public static Dictionary<int, string> ParseDcList(string? text)
        {
            var result = new Dictionary<int, string>(DefaultDcs);

            if (string.IsNullOrWhiteSpace(text))
                return result;

            foreach (var rawLine in text.Split('\n'))
            {
                var line = rawLine.Trim();
                if (string.IsNullOrEmpty(line) || !line.Contains(':')) continue;

                var idx = line.IndexOf(':');
                var numStr = line[..idx].Trim();
                var ip = line[(idx + 1)..].Trim();

                if (int.TryParse(numStr, out var num) && ip.Length > 0)
                    result[num] = ip;
            }

            return result;
        }

        public static (string Tg, string Tme) BuildProxyLinks(string publicIp, int port, string secretHex)
        {
            var tg = $"tg://proxy?server={publicIp}&port={port}&secret={secretHex}";
            var tme = $"https://t.me/proxy?server={publicIp}&port={port}&secret={secretHex}";
            return (tg, tme);
        }
    }

    /// <summary>
    /// Асинхронный MTProto-прокси. Запускается на своём TcpListener в фоновой задаче.
    /// </summary>
    public class MtProxyServer
    {
        public string Host { get; }
        public int Port { get; }
        public string SecretHex { get; }
        public byte[] Secret { get; }
        public Dictionary<int, string> Dcs { get; }
        public int DefaultDc { get; }
        public Action<string> OnLog { get; }
        public MtProxyStats Stats { get; } = new();

        private TcpListener? _listener;
        private CancellationTokenSource? _cts;
        private Task? _serveTask;

        public MtProxyServer(string host, int port, string secretHex, Dictionary<int, string>? dcs = null,
            int defaultDc = 2, Action<string>? onLog = null)
        {
            Host = host;
            Port = port;
            SecretHex = secretHex;
            Secret = Convert.FromHexString(secretHex);
            Dcs = dcs ?? new Dictionary<int, string>(MtprotoConstants.DefaultDcs);
            DefaultDc = defaultDc;
            OnLog = onLog ?? (msg => Logger.Log($"[MTProxy] {msg}"));
        }

        public bool IsRunning => _serveTask != null && !_serveTask.IsCompleted;

        public void Start()
        {
            if (IsRunning) return;

            _cts = new CancellationTokenSource();
            _serveTask = Task.Run(() => ServeAsync(_cts.Token));
        }

        public void Stop()
        {
            try { _cts?.Cancel(); } catch { /* ignore */ }
            try { _listener?.Stop(); } catch { /* ignore */ }

            _serveTask = null;
        }

        private async Task ServeAsync(CancellationToken token)
        {
            var bindAddress = Host == "0.0.0.0" ? IPAddress.Any : IPAddress.Parse(Host);

            try
            {
                _listener = new TcpListener(bindAddress, Port);
                _listener.Start();
            }
            catch (Exception error)
            {
                OnLog($"Не удалось запустить прокси на {Host}:{Port} — {error.Message}");
                return;
            }

            OnLog($"MTProto прокси запущен на {Host}:{Port}");

            try
            {
                while (!token.IsCancellationRequested)
                {
                    TcpClient client;

                    try
                    {
                        client = await _listener.AcceptTcpClientAsync(token);
                    }
                    catch (OperationCanceledException)
                    {
                        break;
                    }
                    catch (ObjectDisposedException)
                    {
                        break;
                    }

                    _ = Task.Run(() => HandleClientAsync(client, token), token);
                }
            }
            catch (Exception error)
            {
                OnLog($"Прокси остановлен с ошибкой: {error.Message}");
            }
        }

        private async Task HandleClientAsync(TcpClient client, CancellationToken token)
        {
            var peer = client.Client.RemoteEndPoint?.ToString() ?? "unknown";
            Interlocked.Increment(ref Stats.TotalConnections);
            Interlocked.Increment(ref Stats.ActiveConnections);

            try
            {
                await ProxyClientAsync(client, token);
            }
            catch (ClientHandshakeException error)
            {
                OnLog($"Отклонено соединение {peer}: {error.Message}");
            }
            catch (EndOfStreamException)
            {
                OnLog($"Соединение {peer} оборвалось до завершения handshake");
            }
            catch (IOException)
            {
                OnLog($"Соединение {peer} оборвалось до завершения handshake");
            }
            catch (Exception error)
            {
                OnLog($"Ошибка соединения {peer}: {error.Message}");
            }
            finally
            {
                Interlocked.Decrement(ref Stats.ActiveConnections);
                client.Close();
            }
        }

        private async Task ProxyClientAsync(TcpClient client, CancellationToken token)
        {
            var stream = client.GetStream();

            var header = new byte[MtprotoConstants.HandshakeLen];
            await stream.ReadExactlyAsync(header, token);

            if (header[0] == 0xEF)
                throw new ClientHandshakeException("bad first byte");

            var firstInt = BitConverter.ToUInt32(header, 0);
            var secondInt = BitConverter.ToUInt32(header, 4);

            if (MtprotoConstants.BadFirstInts.Contains(firstInt) || secondInt == 0)
                throw new ClientHandshakeException("bad signature");

            var (decryptKey, decryptIv, encryptKey, encryptIv) = MakeKeys(header, Secret);

            using var decryptor = new AesCtr(decryptKey, decryptIv);
            using var encryptor = new AesCtr(encryptKey, encryptIv);

            var decryptedHeader = decryptor.Update(header);
            encryptor.Update(header); // синхронизируем keystream шифрования

            var tag = decryptedHeader[56..60];

            byte[] dcTagBytes;

            if (tag.SequenceEqual(MtprotoConstants.TagAbridged))
            {
                dcTagBytes = new byte[] { 0xef };
            }
            else if (tag.SequenceEqual(MtprotoConstants.TagIntermediate) || tag.SequenceEqual(MtprotoConstants.TagPaddedIntermediate))
            {
                dcTagBytes = MtprotoConstants.TagIntermediate;
            }
            else
            {
                throw new ClientHandshakeException("неизвестный тег протокола (неверный secret?)");
            }

            var dcNumRaw = BitConverter.ToInt16(decryptedHeader, 60);
            var dcNum = Math.Abs((int)dcNumRaw);
            if (dcNum == 0) dcNum = DefaultDc;

            if (!Dcs.TryGetValue(dcNum, out var dcIp))
            {
                if (!Dcs.TryGetValue(DefaultDc, out dcIp))
                    throw new ClientHandshakeException($"нет IP для DC{dcNum}");
            }

            OnLog($"Handshake OK, протокол={Convert.ToHexString(tag).ToLowerInvariant()}, DC{dcNum}={dcIp}");

            TcpClient dcClient;

            try
            {
                dcClient = new TcpClient();
                await dcClient.ConnectAsync(dcIp!, MtprotoConstants.DcPort, token);
            }
            catch (Exception error)
            {
                OnLog($"Не удалось подключиться к DC{dcNum} ({dcIp}): {error.Message}");
                return;
            }

            OnLog($"Соединение с DC{dcNum} ({dcIp}) установлено, начинаю релей");

            using (dcClient)
            {
                var dcStream = dcClient.GetStream();

                await dcStream.WriteAsync(dcTagBytes, token);
                await dcStream.FlushAsync(token);

                var clientToDc = PipeClientToDcAsync(stream, dcStream, decryptor, token);
                var dcToClient = PipeDcToClientAsync(dcStream, stream, encryptor, token);

                await Task.WhenAll(clientToDc, dcToClient);
            }
        }

        private static async Task PipeClientToDcAsync(NetworkStream reader, NetworkStream dcWriter, AesCtr decryptor, CancellationToken token)
        {
            var buffer = new byte[16384];

            try
            {
                while (true)
                {
                    var n = await reader.ReadAsync(buffer, token);
                    if (n == 0) break;

                    var decrypted = decryptor.Update(buffer[..n]);
                    await dcWriter.WriteAsync(decrypted, token);
                    await dcWriter.FlushAsync(token);
                }
            }
            catch (IOException) { /* соединение оборвалось */ }
            catch (OperationCanceledException) { /* остановка сервера */ }
            finally
            {
                try { dcWriter.Close(); } catch { /* ignore */ }
            }
        }

        private static async Task PipeDcToClientAsync(NetworkStream dcReader, NetworkStream writer, AesCtr encryptor, CancellationToken token)
        {
            var buffer = new byte[16384];

            try
            {
                while (true)
                {
                    var n = await dcReader.ReadAsync(buffer, token);
                    if (n == 0) break;

                    var encrypted = encryptor.Update(buffer[..n]);
                    await writer.WriteAsync(encrypted, token);
                    await writer.FlushAsync(token);
                }
            }
            catch (IOException) { /* соединение оборвалось */ }
            catch (OperationCanceledException) { /* остановка сервера */ }
            finally
            {
                try { writer.Close(); } catch { /* ignore */ }
            }
        }

        /// <summary>Считает ключи/iv на приём (decrypt) и отправку (encrypt) для клиента.</summary>
        internal static (byte[] DecryptKey, byte[] DecryptIv, byte[] EncryptKey, byte[] EncryptIv) MakeKeys(byte[] header, byte[] secret)
        {
            var decryptKeyRaw = header[8..40];
            var decryptIv = header[40..56];

            // reversed_header = header[55:7:-1] -> реверс header[8:56] (48 байт)
            var reversedHeader = new byte[48];
            for (var i = 0; i < 48; i++)
                reversedHeader[i] = header[55 - i];

            var encryptKeyRaw = reversedHeader[0..32];
            var encryptIv = reversedHeader[32..48];

            var decryptKey = SHA256.HashData(Concat(decryptKeyRaw, secret));
            var encryptKey = SHA256.HashData(Concat(encryptKeyRaw, secret));

            return (decryptKey, decryptIv, encryptKey, encryptIv);
        }

        internal static byte[] Concat(byte[] a, byte[] b)
        {
            var result = new byte[a.Length + b.Length];
            Buffer.BlockCopy(a, 0, result, 0, a.Length);
            Buffer.BlockCopy(b, 0, result, a.Length, b.Length);
            return result;
        }
    }
}
