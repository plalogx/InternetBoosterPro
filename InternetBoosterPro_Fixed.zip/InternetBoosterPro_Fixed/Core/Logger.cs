using System;
using System.IO;

namespace InternetBoosterPro.Core
{
    /// <summary>
    /// Простое файловое логирование. Аналог core/logger.py.
    /// </summary>
    public static class Logger
    {
        private const string LogDir = "logs";
        private const string LogFile = "logs/app.log";
        private static readonly object Lock = new();

        static Logger()
        {
            Directory.CreateDirectory(LogDir);
        }

        public static void Log(string message)
        {
            try
            {
                lock (Lock)
                {
                    var line = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss,fff} | {message}{Environment.NewLine}";
                    File.AppendAllText(LogFile, line, System.Text.Encoding.UTF8);
                }
            }
            catch
            {
                // логирование не должно ронять приложение
            }
        }

        public static string GetLogs()
        {
            try
            {
                lock (Lock)
                {
                    return File.Exists(LogFile) ? File.ReadAllText(LogFile, System.Text.Encoding.UTF8) : "";
                }
            }
            catch
            {
                return "";
            }
        }
    }
}
