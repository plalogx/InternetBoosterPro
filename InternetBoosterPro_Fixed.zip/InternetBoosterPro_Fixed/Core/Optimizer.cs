using System;
using System.Diagnostics;

namespace InternetBoosterPro.Core
{
    /// <summary>
    /// Оптимизация сетевых параметров (полная и лёгкая). Аналог core/optimizer.py.
    /// </summary>
    public static class Optimizer
    {
        // Полная оптимизация — запускается пользователем вручную ("Оптимизировать сеть")
        public static readonly string[] FullOptimizeCommands =
        {
            "ipconfig /flushdns",
            "arp -d *",
            "nbtstat -R",
            "netsh int tcp set global autotuninglevel=normal",
            "netsh int tcp set global rss=enabled",
            "netsh int tcp set global ecncapability=disabled",
            "netsh winsock reset",
        };

        // Лёгкая очистка — безопасно вызывать регулярно (по кулдауну), без сброса Winsock
        public static readonly string[] QuickCleanCommands =
        {
            "ipconfig /flushdns",
            "arp -d *",
            "netsh int tcp set global autotuninglevel=normal",
        };

        public static bool RunCommand(string command)
        {
            try
            {
                var psi = new ProcessStartInfo
                {
                    FileName = "cmd.exe",
                    Arguments = $"/c {command}",
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                };

                using var process = Process.Start(psi);
                if (process == null) return false;

                process.WaitForExit(30_000);
                return process.ExitCode == 0;
            }
            catch (Exception error)
            {
                Logger.Log($"Ошибка команды '{command}': {error.Message}");
                return false;
            }
        }

        public static bool Optimize()
        {
            Logger.Log("Начата полная оптимизация сети");

            var success = true;

            foreach (var command in FullOptimizeCommands)
            {
                if (RunCommand(command))
                    Logger.Log($"Выполнено: {command}");
                else
                {
                    success = false;
                    Logger.Log($"Не удалось выполнить: {command}");
                }
            }

            Logger.Log(success ? "Оптимизация завершена успешно" : "Оптимизация завершена с ошибками");
            return success;
        }

        public static bool QuickClean()
        {
            Logger.Log("Автоматическая очистка сетевых параметров (по расписанию)");

            var success = true;

            foreach (var command in QuickCleanCommands)
            {
                if (!RunCommand(command))
                    success = false;
            }

            Logger.Log(success ? "Автоочистка завершена" : "Автоочистка завершена с ошибками");
            return success;
        }
    }
}
