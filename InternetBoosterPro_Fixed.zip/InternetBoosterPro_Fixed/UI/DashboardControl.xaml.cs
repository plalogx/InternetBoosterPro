using System;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using UserControl = System.Windows.Controls.UserControl;
using System.Windows.Threading;
using InternetBoosterPro.Core;

namespace InternetBoosterPro.UI
{
    public partial class DashboardControl : UserControl
    {
        private readonly AppConfig _config;
        private readonly DispatcherTimer _timer;

        public DashboardControl()
        {
            InitializeComponent();

            _config = ConfigManager.Load();

            _timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
            _timer.Tick += (_, _) => UpdateStatus();
            _timer.Start();

            AutoOptimizer.Instance.Tick += OnAutoTick;
            AutoOptimizer.Instance.Optimized += OnAutoOptimized;

            AutoOptimizer.Instance.SetInterval(_config.Interval);
            AutoOptimizer.Instance.SetNotifications(_config.Notifications);

            if (_config.AutoOptimize)
            {
                AutoOptimizer.Instance.Start();
                AutoButton.Content = "⏸ Остановить автоочистку (КД)";
            }
        }

        private void AutoButton_Click(object sender, RoutedEventArgs e)
        {
            if (AutoOptimizer.Instance.Enabled)
            {
                AutoOptimizer.Instance.Stop();
                AutoButton.Content = "▶ Включить автоочистку (КД)";
            }
            else
            {
                AutoOptimizer.Instance.Start();
                AutoButton.Content = "⏸ Остановить автоочистку (КД)";
            }
        }

        private void OnAutoTick(int secondsLeft)
        {
            Dispatcher.Invoke(() =>
            {
                secondsLeft = Math.Max(secondsLeft, 0);
                var minutes = secondsLeft / 60;
                var seconds = secondsLeft % 60;
                CountdownLabel.Text = $"До автоочистки: {minutes:D2}:{seconds:D2}";
            });
        }

        private void OnAutoOptimized()
        {
            Logger.Log("Выполнена автоочистка по КД");
        }

        private void UpdateStatus()
        {
            var background = InternetBoosterPro.Core.Background.Instance;

            StatusText.Text = background.Adapter != null ? "🟢 Интернет работает" : "🔴 Нет соединения";
            AdapterLabel.Text = $"Адаптер: {background.Adapter ?? "--"}";
            LossLabel.Text = $"Потери пакетов: {background.PacketLoss}";
            SpeedLabel.Text = $"Скорость: ↓{background.Download} / ↑{background.Upload} KB/s";

            if (!AutoOptimizer.Instance.Enabled)
                CountdownLabel.Text = "До автоочистки: выключено";
        }

        private void OptimizeButton_Click(object sender, RoutedEventArgs e)
        {
            OptimizeButton.Content = "⏳ Оптимизация...";
            OptimizeButton.IsEnabled = false;

            Logger.Log("Оптимизация запущена из Dashboard");

            new Thread(() =>
            {
                Optimizer.Optimize();

                Dispatcher.Invoke(() =>
                {
                    OptimizeButton.Content = "⚡ Оптимизировать сеть";
                    OptimizeButton.IsEnabled = true;
                });
            })
            { IsBackground = true }.Start();
        }
    }
}
