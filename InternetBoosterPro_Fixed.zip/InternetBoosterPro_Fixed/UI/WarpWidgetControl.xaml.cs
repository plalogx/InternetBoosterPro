using System;
using System.Windows;
using System.Windows.Controls;
using UserControl = System.Windows.Controls.UserControl;
using InternetBoosterPro.Core;

namespace InternetBoosterPro.UI
{
    public partial class WarpWidgetControl : UserControl
    {
        private readonly WarpManager _warp = new();

        public WarpWidgetControl()
        {
            InitializeComponent();
            StatusClicked();
        }

        private string Run(params string[] args)
        {
            if (!_warp.Available)
            {
                MessageBox.Show("Cloudflare WARP не установлен.", "Ошибка");
                return "";
            }

            try
            {
                var (_, text) = args[0] switch
                {
                    "status" => _warp.Status(),
                    "connect" => _warp.Connect(),
                    "disconnect" => _warp.Disconnect(),
                    "register" => _warp.Register(),
                    _ => (false, ""),
                };

                OutputBox.AppendText("> warp-cli " + string.Join(" ", args) + Environment.NewLine);
                OutputBox.AppendText(text + Environment.NewLine + Environment.NewLine);
                OutputBox.ScrollToEnd();

                return text;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Ошибка");
                return "";
            }
        }

        private void StatusClicked()
        {
            if (!_warp.Available)
            {
                StatusText.Text = "⚠ WARP не установлен";
                return;
            }

            if (!_warp.IsRegistered())
            {
                StatusText.Text = "⚪ WARP не зарегистрирован";
                return;
            }

            var text = Run("status");

            if (_warp.IsConnected())
                StatusText.Text = "🟢 WARP подключён";
            else if (WarpManager.IsDisconnectedText(text))
                StatusText.Text = "🔴 WARP отключён";
            else
                StatusText.Text = "⚪ Не удалось определить состояние";
        }

        private void StatusButton_Click(object sender, RoutedEventArgs e) => StatusClicked();

        private void ConnectButton_Click(object sender, RoutedEventArgs e)
        {
            Run("connect");
            StatusClicked();
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            Run("register");
            StatusClicked();
        }

        private void DisconnectButton_Click(object sender, RoutedEventArgs e)
        {
            Run("disconnect");
            StatusClicked();
        }
    }
}
