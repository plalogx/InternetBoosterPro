using System;
using System.Diagnostics;
using System.Net.Http;
using System.Windows;
using System.Windows.Controls;
using UserControl = System.Windows.Controls.UserControl;
using InternetBoosterPro.Core;

namespace InternetBoosterPro.UI
{
    public partial class Socks5WidgetControl : UserControl
    {
        private readonly AppConfig _config;
        private Socks5ProxyServer? _server;
        private static readonly HttpClient HttpClient = new() { Timeout = TimeSpan.FromSeconds(4) };

        public Socks5WidgetControl()
        {
            InitializeComponent();

            _config = ConfigManager.Load();
            var s5 = _config.Socks5;

            IpBox.Text = string.IsNullOrEmpty(s5.Ip) ? "0.0.0.0" : s5.Ip;
            PublicIpBox.Text = s5.PublicIp;
            PortBox.Text = (s5.Port == 0 ? 1080 : s5.Port).ToString();
            AuthCheck.IsChecked = s5.AuthEnabled;
            UsernameBox.Text = s5.Username;
            PasswordBox.Password = s5.Password;
            WarpCheck.IsChecked = s5.UseWarp;

            UpdateAuthFieldsEnabled();
        }

        private void AuthCheck_Changed(object sender, RoutedEventArgs e) => UpdateAuthFieldsEnabled();

        private void UpdateAuthFieldsEnabled()
        {
            var enabled = AuthCheck.IsChecked == true;
            UsernameBox.IsEnabled = enabled;
            PasswordBox.IsEnabled = enabled;
        }

        private void TestWarp_Click(object sender, RoutedEventArgs e)
        {
            var warp = new WarpManager();

            if (!warp.Available)
            {
                MessageBox.Show(
                    "Cloudflare WARP (warp-cli) не установлен на этом компьютере. Установите его, чтобы использовать эту опцию.",
                    "WARP не найден", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (warp.IsConnected())
                MessageBox.Show("🟢 WARP подключён и работает.", "Cloudflare WARP");
            else
                MessageBox.Show(
                    "🔴 WARP установлен, но не подключён. Подключите его во вкладке ☁ WARP, либо включите галочку выше — прокси попробует включить его сам при запуске.",
                    "Cloudflare WARP", MessageBoxButton.OK, MessageBoxImage.Warning);
        }

        private Socks5Config CurrentSettings() => new()
        {
            Ip = string.IsNullOrWhiteSpace(IpBox.Text) ? "0.0.0.0" : IpBox.Text.Trim(),
            PublicIp = PublicIpBox.Text.Trim(),
            Port = int.TryParse(PortBox.Text, out var p) ? p : 1080,
            AuthEnabled = AuthCheck.IsChecked == true,
            Username = UsernameBox.Text.Trim(),
            Password = PasswordBox.Password,
            UseWarp = WarpCheck.IsChecked == true,
        };

        private void SaveSettings_Click(object sender, RoutedEventArgs e)
        {
            var settings = CurrentSettings();

            if (settings.AuthEnabled && string.IsNullOrEmpty(settings.Username))
            {
                MessageBox.Show(
                    "Если включена авторизация, нужно указать логин (пароль может быть пустым, но так делать не стоит).",
                    "Не указан логин", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            _config.Socks5 = settings;
            ConfigManager.Save(_config);
            Logger.Log("SOCKS5: настройки сохранены");

            StatusLabel.Text = "💾 Настройки сохранены";
            StatusLabel.Foreground = System.Windows.Media.Brushes.LightGreen;
        }

        private void ReloadSettings_Click(object sender, RoutedEventArgs e)
        {
            var s5 = ConfigManager.Load().Socks5;

            IpBox.Text = string.IsNullOrEmpty(s5.Ip) ? "0.0.0.0" : s5.Ip;
            PublicIpBox.Text = s5.PublicIp;
            PortBox.Text = (s5.Port == 0 ? 1080 : s5.Port).ToString();
            AuthCheck.IsChecked = s5.AuthEnabled;
            UsernameBox.Text = s5.Username;
            PasswordBox.Password = s5.Password;
            UpdateAuthFieldsEnabled();
            WarpCheck.IsChecked = s5.UseWarp;
        }

        private void StartProxy_Click(object sender, RoutedEventArgs e)
        {
            var settings = CurrentSettings();

            if (settings.AuthEnabled && string.IsNullOrEmpty(settings.Username))
            {
                MessageBox.Show("Если включена авторизация, нужно указать логин.",
                    "Не указан логин", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (_server != null && _server.IsRunning)
            {
                MessageBox.Show("Сначала остановите текущий прокси.", "Прокси уже запущен");
                return;
            }

            _server = new Socks5ProxyServer(
                settings.Ip, settings.Port,
                settings.AuthEnabled ? settings.Username : null,
                settings.AuthEnabled ? settings.Password : null,
                settings.UseWarp,
                HandleServerLog);

            _server.Start();

            var firewallNote = OpenFirewallPort(settings.Port);

            StatusLabel.Text = $"🟢 Прокси запущен на {settings.Ip}:{settings.Port}";
            StatusLabel.Foreground = System.Windows.Media.Brushes.LightGreen;

            var publicIp = string.IsNullOrEmpty(settings.PublicIp) ? DetectPublicIp() : settings.PublicIp;

            if (!string.IsNullOrEmpty(publicIp))
            {
                PublicIpBox.Text = publicIp;

                InfoBox.Text = settings.AuthEnabled
                    ? $"SOCKS5 {publicIp}:{settings.Port} (логин: {settings.Username}, пароль: {settings.Password})"
                    : $"SOCKS5 {publicIp}:{settings.Port} (без авторизации)";
            }
            else
            {
                InfoBox.Text = "";
                MessageBox.Show(
                    "Заполните поле «Публичный IP» вручную и нажмите «Запустить прокси» ещё раз.",
                    "Не удалось определить внешний IP", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

            Logger.Log($"SOCKS5 прокси запущен на {settings.Ip}:{settings.Port}. {firewallNote}");
        }

        private static string OpenFirewallPort(int port)
        {
            if (!OperatingSystem.IsWindows())
                return "netsh недоступен (не Windows) — брандмауэр не тронут.";

            if (!Admin.IsAdmin())
            {
                return "Нет прав администратора — правило брандмауэра НЕ создано. " +
                       "Перезапустите приложение от имени администратора, либо откройте порт вручную.";
            }

            var ruleName = $"InternetBoosterPro SOCKS5 {port}";

            try
            {
                var psi = new ProcessStartInfo
                {
                    FileName = "netsh",
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                };

                foreach (var arg in new[]
                         {
                             "advfirewall", "firewall", "add", "rule",
                             $"name={ruleName}", "dir=in", "action=allow", "protocol=TCP", $"localport={port}",
                         })
                    psi.ArgumentList.Add(arg);

                using var process = Process.Start(psi);
                process?.WaitForExit(15_000);

                return $"Правило брандмауэра '{ruleName}' добавлено (или уже существовало).";
            }
            catch (Exception error)
            {
                return $"Не удалось добавить правило брандмауэра: {error.Message}";
            }
        }

        private void DetectPublicIp_Click(object sender, RoutedEventArgs e)
        {
            var ip = DetectPublicIp();

            if (!string.IsNullOrEmpty(ip))
                PublicIpBox.Text = ip;
            else
                MessageBox.Show(
                    "Нет доступа в интернет или сервис определения IP недоступен. Введите публичный IP вручную.",
                    "Не удалось определить IP", MessageBoxButton.OK, MessageBoxImage.Warning);
        }

        private void StopProxy_Click(object sender, RoutedEventArgs e)
        {
            _server?.Stop();
            _server = null;

            StatusLabel.Text = "⚪ Прокси остановлен";
            StatusLabel.Foreground = System.Windows.Media.Brushes.Orange;
            InfoBox.Clear();

            Logger.Log("SOCKS5 прокси остановлен");
        }

        private void HandleServerLog(string message) => Logger.Log($"[SOCKS5] {message}");

        private static string DetectPublicIp()
        {
            string[] services =
            {
                "https://api.ipify.org",
                "https://ifconfig.me/ip",
                "https://icanhazip.com",
            };

            foreach (var url in services)
            {
                try
                {
                    var ip = HttpClient.GetStringAsync(url).GetAwaiter().GetResult().Trim();
                    if (!string.IsNullOrEmpty(ip))
                        return ip;
                }
                catch
                {
                    // пробуем следующий сервис
                }
            }

            return "";
        }

        private void CopyInfo_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(InfoBox.Text))
            {
                MessageBox.Show("Сначала запустите прокси.", "Пусто");
                return;
            }

            Clipboard.SetText(InfoBox.Text);
            MessageBox.Show("Параметры скопированы.", "Готово");
        }
    }
}
