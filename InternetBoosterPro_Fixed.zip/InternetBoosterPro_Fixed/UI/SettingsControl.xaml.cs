using System;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using UserControl = System.Windows.Controls.UserControl;
using InternetBoosterPro.Core;

namespace InternetBoosterPro.UI
{
    public partial class SettingsControl : UserControl
    {
        private readonly AppConfig _config;

        public SettingsControl()
        {
            InitializeComponent();

            _config = ConfigManager.Load();

            if (!Admin.IsAdmin())
                AdminWarningPanel.Visibility = Visibility.Visible;

            foreach (var name in DnsManager.DnsList.Keys)
                DnsCombo.Items.Add(name);

            if (DnsManager.DnsList.ContainsKey(_config.Dns))
                DnsCombo.SelectedItem = _config.Dns;
            else
                DnsCombo.Text = _config.Dns;

            IntervalBox.Text = _config.Interval.ToString();
            AutorunCheck.IsChecked = _config.Autorun || Startup.IsStartupEnabled();
            NotifyCheck.IsChecked = _config.Notifications;
            AutoOptimizeCheck.IsChecked = _config.AutoOptimize;
            GamingCheck.IsChecked = _config.GamingMode;
        }

        private void RestartAsAdmin_Click(object sender, RoutedEventArgs e) => Admin.RequireAdmin();

        private void ApplyDns_Click(object sender, RoutedEventArgs e)
        {
            var name = DnsCombo.SelectedItem as string ?? DnsCombo.Text ?? "Google";
            StatusLabel.Text = "Применяю DNS...";

            new Thread(() =>
            {
                var ok = DnsManager.SetDns(name);

                Dispatcher.Invoke(() =>
                {
                    StatusLabel.Text = ok ? $"DNS {name} применён" : "Не удалось применить DNS";
                });
            })
            { IsBackground = true }.Start();
        }

        private void ResetDns_Click(object sender, RoutedEventArgs e)
        {
            StatusLabel.Text = "Сбрасываю DNS...";

            new Thread(() =>
            {
                var ok = DnsManager.ResetDns();

                Dispatcher.Invoke(() =>
                {
                    StatusLabel.Text = ok ? "DNS возвращён на автоматический (DHCP)" : "Не удалось сбросить DNS";
                });
            })
            { IsBackground = true }.Start();
        }

        private void ApplyTcp_Click(object sender, RoutedEventArgs e)
        {
            StatusLabel.Text = "Оптимизирую TCP...";

            new Thread(() =>
            {
                TcpTools.OptimizeTcp();

                Dispatcher.Invoke(() => StatusLabel.Text = "Параметры TCP оптимизированы");
            })
            { IsBackground = true }.Start();
        }

        private void ResetNetwork_Click(object sender, RoutedEventArgs e)
        {
            var answer = MessageBox.Show(
                "Сбросить настройки TCP/IP и Winsock?\nПотребуется перезагрузка компьютера.",
                "Подтверждение", MessageBoxButton.YesNo);

            if (answer != MessageBoxResult.Yes)
                return;

            Backup.SaveBackup(_config);
            StatusLabel.Text = "Сбрасываю сеть...";

            new Thread(() =>
            {
                TcpTools.ResetTcp();

                Dispatcher.Invoke(() =>
                    StatusLabel.Text = "Сеть сброшена. Перезагрузите компьютер для применения изменений.");
            })
            { IsBackground = true }.Start();
        }

        private void SaveSettings_Click(object sender, RoutedEventArgs e)
        {
            _config.Dns = DnsCombo.SelectedItem as string ?? DnsCombo.Text ?? "Google";
            _config.Interval = int.TryParse(IntervalBox.Text, out var interval) ? Math.Max(1, interval) : 10;
            _config.Autorun = AutorunCheck.IsChecked == true;
            _config.Notifications = NotifyCheck.IsChecked == true;
            _config.AutoOptimize = AutoOptimizeCheck.IsChecked == true;
            _config.GamingMode = GamingCheck.IsChecked == true;

            ConfigManager.Save(_config);

            if (_config.Autorun)
                Startup.EnableStartup();
            else
                Startup.DisableStartup();

            if (_config.GamingMode)
                GamingMode.Instance.Enable();
            else
                GamingMode.Instance.Disable();

            AutoOptimizer.Instance.SetInterval(_config.Interval);
            AutoOptimizer.Instance.SetNotifications(_config.Notifications);

            if (_config.AutoOptimize)
                AutoOptimizer.Instance.Start();
            else
                AutoOptimizer.Instance.Stop();

            Logger.Log("Настройки сохранены");
            StatusLabel.Text = "✅ Настройки сохранены";
        }
    }
}
