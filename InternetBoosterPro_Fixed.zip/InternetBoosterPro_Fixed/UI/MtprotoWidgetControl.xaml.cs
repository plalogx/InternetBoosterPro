using System;
using System.Diagnostics;
using System.Net.Http;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using UserControl = System.Windows.Controls.UserControl;
using InternetBoosterPro.Core;

namespace InternetBoosterPro.UI
{
    public partial class MtprotoWidgetControl : UserControl
    {
        private readonly AppConfig _config;
        private MtProxyServer? _server;
        private static readonly HttpClient HttpClient = new() { Timeout = TimeSpan.FromSeconds(4) };

        private static readonly string DefaultDcText = BuildDefaultDcText();

        private static string BuildDefaultDcText()
        {
            var lines = new System.Collections.Generic.List<string>();
            foreach (var kv in MtprotoConstants.DefaultDcs)
                lines.Add($"{kv.Key}:{kv.Value}");
            return string.Join("\n", lines);
        }

        public MtprotoWidgetControl()
        {
            InitializeComponent();

            _config = ConfigManager.Load();
            var mt = _config.Mtproto;

            IpBox.Text = string.IsNullOrEmpty(mt.Ip) ? "0.0.0.0" : mt.Ip;
            PublicIpBox.Text = mt.PublicIp;
            PortBox.Text = (mt.Port == 0 ? 8443 : mt.Port).ToString();
            SecretBox.Text = string.IsNullOrEmpty(mt.Secret) ? MtprotoSecret.GenerateShort() : mt.Secret;
            DcBox.Text = string.IsNullOrEmpty(mt.DcsText) ? DefaultDcText : mt.DcsText;
            CfCheck.IsChecked = mt.CfEnabled;
        }

        private void RegenSecret_Click(object sender, RoutedEventArgs e)
        {
            SecretBox.Text = MtprotoSecret.GenerateShort();
        }

        private MtprotoConfig CurrentSettings() => new()
        {
            Ip = string.IsNullOrWhiteSpace(IpBox.Text) ? "0.0.0.0" : IpBox.Text.Trim(),
            PublicIp = PublicIpBox.Text.Trim(),
            Port = int.TryParse(PortBox.Text, out var p) ? p : 8443,
            Secret = SecretBox.Text.Trim(),
            DcsText = DcBox.Text,
            CfEnabled = CfCheck.IsChecked == true,
        };

        private void SaveSettings_Click(object sender, RoutedEventArgs e)
        {
            var secret = SecretBox.Text.Trim();

            if (!MtprotoSecret.Validate(secret))
            {
                MessageBox.Show(
                    "Secret должен быть строкой из 32 или 64 hex-символов. Нажмите 🔄, чтобы сгенерировать новый.",
                    "Некорректный secret", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            _config.Mtproto = CurrentSettings();
            ConfigManager.Save(_config);
            Logger.Log("MTProto: настройки сохранены");

            StatusLabel.Text = "💾 Настройки сохранены";
            StatusLabel.Foreground = System.Windows.Media.Brushes.LightGreen;
        }

        private void ReloadSettings_Click(object sender, RoutedEventArgs e)
        {
            var mt = ConfigManager.Load().Mtproto;

            IpBox.Text = string.IsNullOrEmpty(mt.Ip) ? "0.0.0.0" : mt.Ip;
            PublicIpBox.Text = mt.PublicIp;
            PortBox.Text = (mt.Port == 0 ? 8443 : mt.Port).ToString();
            SecretBox.Text = string.IsNullOrEmpty(mt.Secret) ? MtprotoSecret.GenerateShort() : mt.Secret;
            DcBox.Text = string.IsNullOrEmpty(mt.DcsText) ? DefaultDcText : mt.DcsText;
            CfCheck.IsChecked = mt.CfEnabled;
        }

        private void TestCloudflare_Click(object sender, RoutedEventArgs e)
        {
            var warp = new WarpManager();

            if (!warp.Available)
            {
                MessageBox.Show(
                    "Cloudflare WARP (warp-cli) не установлен на этом компьютере. Установите Cloudflare WARP, чтобы использовать CF-прокси.",
                    "WARP не найден", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                if (warp.IsConnected())
                    MessageBox.Show("🟢 WARP подключён и работает.", "Cloudflare WARP");
                else
                    MessageBox.Show("🔴 WARP установлен, но не подключён. Подключите его во вкладке ☁ WARP.",
                        "Cloudflare WARP", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void StartProxy_Click(object sender, RoutedEventArgs e)
        {
            var settings = CurrentSettings();

            if (!MtprotoSecret.Validate(settings.Secret))
            {
                MessageBox.Show("Secret должен быть строкой из 32 или 64 hex-символов.",
                    "Некорректный secret", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var dcs = MtprotoConstants.ParseDcList(settings.DcsText);

            if (_server != null && _server.IsRunning)
            {
                MessageBox.Show("Сначала остановите текущий прокси.", "Прокси уже запущен");
                return;
            }

            _server = new MtProxyServer(settings.Ip, settings.Port, settings.Secret, dcs, onLog: HandleServerLog);
            _server.Start();

            var firewallNote = OpenFirewallPort(settings.Port, "MTProxy");

            StatusLabel.Text = $"🟢 Прокси запущен на {settings.Ip}:{settings.Port}";
            StatusLabel.Foreground = System.Windows.Media.Brushes.LightGreen;

            var publicIp = string.IsNullOrEmpty(settings.PublicIp) ? DetectPublicIp() : settings.PublicIp;

            if (!string.IsNullOrEmpty(publicIp))
            {
                PublicIpBox.Text = publicIp;
                var (tgLink, _) = MtprotoConstants.BuildProxyLinks(publicIp, settings.Port, settings.Secret);
                LinkBox.Text = tgLink;
            }
            else
            {
                LinkBox.Text = "";
                MessageBox.Show(
                    "Заполните поле «Публичный IP» вручную (для VPS — это IP сервера, для домашнего ПК — внешний IP роутера) и нажмите «Запустить прокси» ещё раз.",
                    "Не удалось определить внешний IP", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

            Logger.Log($"MTProto прокси запущен на {settings.Ip}:{settings.Port}. {firewallNote}");
        }

        private static string OpenFirewallPort(int port, string tag)
        {
            if (!OperatingSystem.IsWindows())
                return "netsh недоступен (не Windows) — брандмауэр не тронут.";

            if (!Admin.IsAdmin())
            {
                return "Нет прав администратора — правило брандмауэра НЕ создано. " +
                       "Перезапустите приложение от имени администратора, либо откройте порт вручную.";
            }

            var ruleName = $"InternetBoosterPro {tag} {port}";

            try
            {
                var psi = new ProcessStartInfo
                {
                    FileName = "netsh",
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                };

                foreach (var arg in new[]
                         {
                             "advfirewall", "firewall", "add", "rule",
                             $"name={ruleName}", "dir=in", "action=allow", "protocol=TCP", $"localport={port}",
                         })
                    psi.ArgumentList.Add(arg);

                using var process = Process.Start(psi);
                process?.WaitForExit(15_000);

                return $"Правило брандмауэра '{ruleName}' добавлено (или уже существовало).";
            }
            catch (Exception error)
            {
                return $"Не удалось добавить правило брандмауэра: {error.Message}";
            }
        }

        private void DetectPublicIp_Click(object sender, RoutedEventArgs e)
        {
            var ip = DetectPublicIp();

            if (!string.IsNullOrEmpty(ip))
                PublicIpBox.Text = ip;
            else
                MessageBox.Show(
                    "Нет доступа в интернет или сервис определения IP недоступен. Введите публичный IP вручную.",
                    "Не удалось определить IP", MessageBoxButton.OK, MessageBoxImage.Warning);
        }

        private void RunDiagnostics_Click(object sender, RoutedEventArgs e)
        {
            if (_server == null || !_server.IsRunning)
            {
                MessageBox.Show("Сначала нажмите «▶ Запустить прокси».", "Прокси не запущен");
                return;
            }

            var settings = CurrentSettings();

            SelftestButton.IsEnabled = false;
            SelftestButton.Content = "⏳ Проверяю...";

            new Thread(() =>
            {
                var (ok, details) = MtprotoSelftest.RunSelftest(
                    settings.Ip, settings.Port, settings.Secret,
                    log: m => Logger.Log($"[Selftest] {m}"));

                Dispatcher.Invoke(() => OnSelftestFinished(ok, details));
            })
            { IsBackground = true }.Start();
        }

        private void OnSelftestFinished(bool ok, string details)
        {
            SelftestButton.IsEnabled = true;
            SelftestButton.Content = "🩺 Диагностика";

            Logger.Log($"[Selftest] {(ok ? "OK" : "FAIL")}: {details}");

            MessageBox.Show(details, ok ? "Диагностика: успех" : "Диагностика: проблема",
                MessageBoxButton.OK, ok ? MessageBoxImage.Information : MessageBoxImage.Warning);
        }

        private void StopProxy_Click(object sender, RoutedEventArgs e)
        {
            _server?.Stop();
            _server = null;

            StatusLabel.Text = "⚪ Прокси остановлен";
            StatusLabel.Foreground = System.Windows.Media.Brushes.Orange;
            LinkBox.Clear();

            Logger.Log("MTProto прокси остановлен");
        }

        private void HandleServerLog(string message) => Logger.Log($"[MTProxy] {message}");

        private static string DetectPublicIp()
        {
            string[] services =
            {
                "https://api.ipify.org",
                "https://ifconfig.me/ip",
                "https://icanhazip.com",
            };

            foreach (var url in services)
            {
                try
                {
                    var ip = HttpClient.GetStringAsync(url).GetAwaiter().GetResult().Trim();
                    if (!string.IsNullOrEmpty(ip))
                        return ip;
                }
                catch
                {
                    // пробуем следующий сервис
                }
            }

            return "";
        }

        private void CopyLink_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(LinkBox.Text))
            {
                MessageBox.Show("Сначала запустите прокси.", "Пусто");
                return;
            }

            Clipboard.SetText(LinkBox.Text);
            MessageBox.Show("Ссылка скопирована.", "Готово");
        }
    }
}
