using System.ComponentModel;
using System.Windows;
using InternetBoosterPro.Tray;

namespace InternetBoosterPro.UI
{
    public partial class MainWindow : Window
    {
        private TrayIconManager? _tray;

        public MainWindow()
        {
            InitializeComponent();

            DashboardTab.Content = new DashboardControl();
            WarpTab.Content = new WarpWidgetControl();
            SettingsTab.Content = new SettingsControl();
            LogsTab.Content = new LogsControl();
            SecretTab.Content = new SecretWidgetControl();
            MtprotoTab.Content = new MtprotoWidgetControl();
            Socks5Tab.Content = new Socks5WidgetControl();

            _tray = new TrayIconManager(this);
            _tray.Show();
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            // не закрывать приложение при закрытии окна - оно сворачивается в трей
            e.Cancel = true;
            Hide();
        }
    }
}
