using System;
using System.Windows;
using System.Windows.Controls;
using UserControl = System.Windows.Controls.UserControl;
using System.Windows.Threading;
using InternetBoosterPro.Core;

namespace InternetBoosterPro.UI
{
    public partial class LogsControl : UserControl
    {
        private readonly DispatcherTimer _timer;

        public LogsControl()
        {
            InitializeComponent();

            Refresh();

            _timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(5) };
            _timer.Tick += (_, _) => Refresh();
            _timer.Start();
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e) => Refresh();

        private void Refresh()
        {
            var content = Logger.GetLogs();

            // показываем только последние строки, чтобы не тормозил интерфейс
            LogText.Text = content.Length > 10000 ? content[^10000..] : content;
            LogText.CaretIndex = LogText.Text.Length;
            LogText.ScrollToEnd();
        }
    }
}
