using System.Windows;
using System.Windows.Controls;
using UserControl = System.Windows.Controls.UserControl;
using InternetBoosterPro.Core;

namespace InternetBoosterPro.UI
{
    public partial class SecretWidgetControl : UserControl
    {
        public SecretWidgetControl()
        {
            InitializeComponent();
        }

        private void GenerateButton_Click(object sender, RoutedEventArgs e)
        {
            SecretBox.Text = MtprotoSecret.GenerateShort();
        }

        private void CopyButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(SecretBox.Text))
            {
                MessageBox.Show("Сначала сгенерируйте секрет.", "Пусто");
                return;
            }

            Clipboard.SetText(SecretBox.Text);
            MessageBox.Show("Секрет скопирован.", "Готово");
        }
    }
}
