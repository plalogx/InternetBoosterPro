using System;
using System.IO;
using System.Windows;
using InternetBoosterPro.Core;
using InternetBoosterPro.UI;
using Application = System.Windows.Application;

namespace InternetBoosterPro
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // Работаем из папки приложения (важно и при запуске из IDE, и из собранного .exe)
            Directory.SetCurrentDirectory(AppContext.BaseDirectory);

            if (!Admin.IsAdmin())
                Logger.Log("Приложение запущено без прав администратора");

            var config = ConfigManager.Load();

            if (config.GamingMode)
                GamingMode.Instance.Enable();

            var window = new MainWindow();

            // запускаем сбор метрик сети в фоне (адаптер, скорость, потери пакетов)
            Background.Instance.Start();

            window.Show();
        }
    }
}
