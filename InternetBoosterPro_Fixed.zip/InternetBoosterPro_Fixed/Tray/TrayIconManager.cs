using System;
using System.Threading;
using System.Windows;
using System.Windows.Forms;
using InternetBoosterPro.Core;
using Application = System.Windows.Application;
using MessageBox = System.Windows.MessageBox;

namespace InternetBoosterPro.Tray
{
    /// <summary>
    /// Иконка приложения в системном трее. Аналог tray/tray_tray_icon.py.
    /// Использует System.Windows.Forms.NotifyIcon (нет прямого аналога QSystemTrayIcon в WPF).
    /// </summary>
    public class TrayIconManager : IDisposable
    {
        private readonly NotifyIcon _notifyIcon;
        private readonly Window _window;

        public TrayIconManager(Window window)
        {
            _window = window;

            _notifyIcon = new NotifyIcon
            {
                Text = "InternetBooster Pro",
                Visible = false,
            };

            var iconPath = System.IO.Path.Combine(AppContext.BaseDirectory, "assets", "icon.ico");

            _notifyIcon.Icon = System.IO.File.Exists(iconPath)
                ? new System.Drawing.Icon(iconPath)
                : System.Drawing.SystemIcons.Application;

            var menu = new ContextMenuStrip();

            var openItem = new ToolStripMenuItem("Открыть");
            var optimizeItem = new ToolStripMenuItem("Оптимизировать сейчас");
            var exitItem = new ToolStripMenuItem("Выход");

            openItem.Click += (_, _) => ShowWindow();
            optimizeItem.Click += (_, _) => OptimizeNow();
            exitItem.Click += (_, _) => ExitApp();

            menu.Items.Add(openItem);
            menu.Items.Add(optimizeItem);
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add(exitItem);

            _notifyIcon.ContextMenuStrip = menu;
            _notifyIcon.DoubleClick += (_, _) => ShowWindow();

            // подключаем показ уведомлений через баллун трея (см. Core.Notifier)
            Notifier.ShowBalloon = ShowBalloon;
        }

        public void Show() => _notifyIcon.Visible = true;

        private void ShowBalloon(string title, string message)
        {
            _notifyIcon.BalloonTipTitle = title;
            _notifyIcon.BalloonTipText = message;
            _notifyIcon.ShowBalloonTip(4000);
        }

        private void ShowWindow()
        {
            _window.Dispatcher.Invoke(() =>
            {
                if (_window.Visibility != Visibility.Visible)
                {
                    _window.Show();
                    _window.WindowState = WindowState.Normal;
                    _window.Activate();
                }
            });
        }

        private static void OptimizeNow()
        {
            new Thread(() => Optimizer.Optimize()) { IsBackground = true }.Start();
        }

        private void ExitApp()
        {
            _notifyIcon.Visible = false;
            Application.Current.Shutdown();
        }

        public void Dispose()
        {
            _notifyIcon.Visible = false;
            _notifyIcon.Dispose();
        }
    }
}
